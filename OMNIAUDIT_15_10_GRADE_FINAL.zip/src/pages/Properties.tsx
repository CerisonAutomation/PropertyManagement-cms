import { useState, useMemo } from "react";
import { motion } from "framer-motion";
import { Search, Filter, MapPin, Bed, Bath, Square, Calendar, Star, Heart } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const Properties = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedType, setSelectedType] = useState("all");
  const [selectedBedrooms, setSelectedBedrooms] = useState("all");
  const [priceRange, setPriceRange] = useState("all");
  const [sortBy, setSortBy] = useState("featured");

  // Sample properties data
  const properties = [
    {
      id: 1,
      title: "Luxury Sea View Apartment",
      type: "apartment",
      location: "Sliema",
      price: 2500,
      bedrooms: 3,
      bathrooms: 2,
      area: 120,
      image: "/api/placeholder/400/300",
      featured: true,
      rating: 4.9,
      reviews: 28,
      amenities: ["WiFi", "AC", "Parking", "Sea View"],
      available: true
    },
    {
      id: 2,
      title: "Historic Valletta Townhouse",
      type: "townhouse",
      location: "Valletta",
      price: 3200,
      bedrooms: 4,
      bathrooms: 3,
      area: 180,
      image: "/api/placeholder/400/300",
      featured: true,
      rating: 4.8,
      reviews: 15,
      amenities: ["WiFi", "AC", "Garden", "Historic"],
      available: true
    },
    {
      id: 3,
      title: "Modern Studio with Terrace",
      type: "studio",
      location: "St. Julian's",
      price: 1800,
      bedrooms: 1,
      bathrooms: 1,
      area: 45,
      image: "/api/placeholder/400/300",
      featured: false,
      rating: 4.7,
      reviews: 42,
      amenities: ["WiFi", "AC", "Terrace", "Modern"],
      available: true
    },
    {
      id: 4,
      title: "Family Villa with Pool",
      type: "villa",
      location: "Mellieha",
      price: 4500,
      bedrooms: 5,
      bathrooms: 4,
      area: 300,
      image: "/api/placeholder/400/300",
      featured: true,
      rating: 5.0,
      reviews: 8,
      amenities: ["WiFi", "AC", "Pool", "Garden", "Parking"],
      available: false
    },
    {
      id: 5,
      title: "Cozy Beach Apartment",
      type: "apartment",
      location: "St. Paul's Bay",
      price: 2200,
      bedrooms: 2,
      bathrooms: 1,
      area: 85,
      image: "/api/placeholder/400/300",
      featured: false,
      rating: 4.6,
      reviews: 19,
      amenities: ["WiFi", "AC", "Beach Access"],
      available: true
    },
    {
      id: 6,
      title: "Penthouse with Panoramic Views",
      type: "penthouse",
      location: "Gzira",
      price: 3800,
      bedrooms: 3,
      bathrooms: 2,
      area: 150,
      image: "/api/placeholder/400/300",
      featured: true,
      rating: 4.9,
      reviews: 12,
      amenities: ["WiFi", "AC", "Terrace", "Premium"],
      available: true
    }
  ];

  const filteredAndSortedProperties = useMemo(() => {
    let filtered = properties.filter(property => {
      const matchesSearch = property.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           property.location.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesType = selectedType === "all" || property.type === selectedType;
      const matchesBedrooms = selectedBedrooms === "all" || property.bedrooms.toString() === selectedBedrooms;
      const matchesPrice = priceRange === "all" || 
                           (priceRange === "0-2000" && property.price <= 2000) ||
                           (priceRange === "2000-3000" && property.price > 2000 && property.price <= 3000) ||
                           (priceRange === "3000+" && property.price > 3000);

      return matchesSearch && matchesType && matchesBedrooms && matchesPrice;
    });

    // Sort properties
    filtered.sort((a, b) => {
      if (sortBy === "price-low") return a.price - b.price;
      if (sortBy === "price-high") return b.price - a.price;
      if (sortBy === "rating") return b.rating - a.rating;
      if (sortBy === "featured") return (b.featured ? 1 : 0) - (a.featured ? 1 : 0);
      return 0;
    });

    return filtered;
  }, [properties, searchTerm, selectedType, selectedBedrooms, priceRange, sortBy]);

  const PropertyCard = ({ property }: { property: any }) => (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      whileHover={{ y: -5 }}
      className="group cursor-pointer"
    >
      <Card className="overflow-hidden border-0 shadow-lg hover:shadow-xl transition-all duration-300">
        <div className="relative">
          <img 
            src={property.image} 
            alt={property.title}
            className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
          />
          <div className="absolute top-3 left-3 flex gap-2">
            {property.featured && <Badge className="bg-primary">Featured</Badge>}
            {!property.available && <Badge variant="destructive">Occupied</Badge>}
          </div>
          <Button
            variant="ghost"
            size="sm"
            className="absolute top-3 right-3 bg-white/80 hover:bg-white text-gray-600"
          >
            <Heart className="w-4 h-4" />
          </Button>
        </div>
        <CardContent className="p-5">
          <div className="flex items-start justify-between mb-2">
            <div>
              <h3 className="font-semibold text-lg text-gray-900 group-hover:text-primary transition-colors">
                {property.title}
              </h3>
              <div className="flex items-center text-sm text-gray-600 mt-1">
                <MapPin className="w-4 h-4 mr-1" />
                {property.location}
              </div>
            </div>
            <div className="text-right">
              <p className="text-2xl font-bold text-primary">€{property.price}</p>
              <p className="text-xs text-gray-500">per month</p>
            </div>
          </div>

          <div className="flex items-center gap-4 text-sm text-gray-600 mb-3">
            <div className="flex items-center">
              <Bed className="w-4 h-4 mr-1" />
              {property.bedrooms} beds
            </div>
            <div className="flex items-center">
              <Bath className="w-4 h-4 mr-1" />
              {property.bathrooms} baths
            </div>
            <div className="flex items-center">
              <Square className="w-4 h-4 mr-1" />
              {property.area}m²
            </div>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Star className="w-4 h-4 text-yellow-400 fill-current" />
              <span className="text-sm font-medium ml-1">{property.rating}</span>
              <span className="text-xs text-gray-500 ml-1">({property.reviews})</span>
            </div>
            <Button size="sm" className="bg-primary hover:bg-gold-light">
              View Details
            </Button>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );

  return (
    <div className="min-h-screen bg-background">
      <Navbar onOpenWizard={() => {}} />
      
      <main className="pt-24 pb-16">
        <div className="section-container">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-12"
          >
            <h1 className="font-serif text-4xl md:text-5xl font-bold text-gray-900 mb-4">
              Premium Properties in Malta
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Discover our handpicked selection of luxury properties across Malta and Gozo. 
              Each home is carefully curated to ensure the highest standards of comfort and style.
            </p>
          </motion.div>

          {/* Filters */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-8"
          >
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Search properties..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              
              <Select value={selectedType} onValueChange={setSelectedType}>
                <SelectTrigger>
                  <SelectValue placeholder="Property Type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="apartment">Apartments</SelectItem>
                  <SelectItem value="villa">Villas</SelectItem>
                  <SelectItem value="townhouse">Townhouses</SelectItem>
                  <SelectItem value="studio">Studios</SelectItem>
                  <SelectItem value="penthouse">Penthouses</SelectItem>
                </SelectContent>
              </Select>

              <Select value={selectedBedrooms} onValueChange={setSelectedBedrooms}>
                <SelectTrigger>
                  <SelectValue placeholder="Bedrooms" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Any</SelectItem>
                  <SelectItem value="1">1 Bed</SelectItem>
                  <SelectItem value="2">2 Beds</SelectItem>
                  <SelectItem value="3">3 Beds</SelectItem>
                  <SelectItem value="4">4+ Beds</SelectItem>
                </SelectContent>
              </Select>

              <Select value={priceRange} onValueChange={setPriceRange}>
                <SelectTrigger>
                  <SelectValue placeholder="Price Range" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Any Price</SelectItem>
                  <SelectItem value="0-2000">€0 - €2,000</SelectItem>
                  <SelectItem value="2000-3000">€2,000 - €3,000</SelectItem>
                  <SelectItem value="3000+">€3,000+</SelectItem>
                </SelectContent>
              </Select>

              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger>
                  <SelectValue placeholder="Sort By" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="featured">Featured</SelectItem>
                  <SelectItem value="price-low">Price: Low to High</SelectItem>
                  <SelectItem value="price-high">Price: High to Low</SelectItem>
                  <SelectItem value="rating">Highest Rated</SelectItem>
                </SelectContent>
              </Select>

              <Button variant="outline" className="w-full">
                <Filter className="w-4 h-4 mr-2" />
                More Filters
              </Button>
            </div>
          </motion.div>

          {/* Results Count */}
          <div className="flex items-center justify-between mb-6">
            <p className="text-gray-600">
              Showing <span className="font-semibold">{filteredAndSortedProperties.length}</span> properties
            </p>
            <div className="flex gap-2">
              <Button variant="outline" size="sm">Map View</Button>
              <Button variant="outline" size="sm">Grid View</Button>
            </div>
          </div>

          {/* Properties Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredAndSortedProperties.map((property) => (
              <PropertyCard key={property.id} property={property} />
            ))}
          </div>

          {/* No Results */}
          {filteredAndSortedProperties.length === 0 && (
            <div className="text-center py-12">
              <p className="text-gray-500 text-lg">No properties found matching your criteria.</p>
              <Button variant="outline" className="mt-4" onClick={() => {
                setSearchTerm("");
                setSelectedType("all");
                setSelectedBedrooms("all");
                setPriceRange("all");
              }}>
                Clear Filters
              </Button>
            </div>
          )}

          {/* Load More */}
          {filteredAndSortedProperties.length > 0 && (
            <div className="text-center mt-12">
              <Button variant="outline" size="lg">
                Load More Properties
              </Button>
            </div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default Properties;
