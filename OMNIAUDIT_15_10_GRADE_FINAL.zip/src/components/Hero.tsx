import { motion, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";
import heroBg from "@/assets/hero-bg.jpg";
import { useCmsSettings } from "@/hooks/use-cms";

interface HeroProps {
  onOpenWizard: () => void;
}

export default function Hero({ onOpenWizard }: HeroProps) {
  const ref = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const imgY = useTransform(scrollYProgress, [0, 1], [0, 150]);
  const textY = useTransform(scrollYProgress, [0, 1], [0, -50]);
  const opacity = useTransform(scrollYProgress, [0, 0.5], [1, 0]);

  const { data: settings } = useCmsSettings();

  // Get hero content from settings or use defaults
  const getSetting = (key: string, defaultValue: any) => {
    const setting = settings?.find(s => s.key === key);
    return setting ? setting.value : defaultValue;
  };

  const heroContent = {
    tagline: getSetting('hero_tagline', "Malta's Premier Property Partner"),
    headline: getSetting('hero_headline', "Maximise your rental income,"),
    highlightedWord: getSetting('hero_highlighted', "effortlessly."),
    description: getSetting('hero_description', "Full-service short-let management across Malta & Gozo. We handle everything — you earn more."),
    ctaText: getSetting('hero_cta_text', "Get Your Free Assessment"),
    secondaryCtaText: getSetting('hero_secondary_cta', "How It Works"),
  };

  const stats = [
    { value: getSetting('stat_revenue', "€2.4M+"), label: "Revenue Generated" },
    { value: getSetting('stat_properties', "45+"), label: "Properties Managed" },
    { value: getSetting('stat_rating', "4.97"), label: "Average Rating" },
    { value: getSetting('stat_occupancy', "94%"), label: "Occupancy Rate" },
  ];

  return (
    <section ref={ref} className="relative min-h-screen flex items-end pb-20 sm:pb-28 overflow-hidden">
      <motion.div className="absolute inset-0" style={{ y: imgY }}>
        <img src={heroBg} alt="Luxury Malta villa with infinity pool overlooking the Mediterranean" className="w-full h-full object-cover scale-110" />
        <div className="absolute inset-0" style={{ background: "var(--gradient-hero-overlay)" }} />
      </motion.div>

      <div className="section-container relative z-10 w-full">
        <motion.div
          style={{ y: textY, opacity }}
          className="max-w-2xl"
        >
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease: "easeOut" }}
          >
            <p className="micro-type text-primary mb-4">{heroContent.tagline}</p>
            <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-semibold text-foreground leading-[1.1] mb-6">
              {heroContent.headline}{" "}
              <span className="gold-text">{heroContent.highlightedWord}</span>
            </h1>
            <p className="text-lg sm:text-xl text-muted-foreground mb-8 max-w-lg leading-relaxed">
              {heroContent.description}
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <button
                onClick={onOpenWizard}
                className="px-8 py-4 text-base font-semibold bg-primary text-primary-foreground rounded hover:bg-gold-light transition-all hover:shadow-lg hover:scale-[1.02]"
              >
                {heroContent.ctaText}
              </button>
              <a
                href="#process"
                className="px-8 py-4 text-base font-medium text-foreground border border-border rounded hover:border-primary hover:text-primary transition-colors text-center"
              >
                {heroContent.secondaryCtaText}
              </a>
            </div>
          </motion.div>
        </motion.div>

        {/* Stats strip */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.6 }}
          className="mt-16 grid grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8"
        >
          {stats.map((stat) => (
            <div key={stat.label} className="text-center lg:text-left">
              <p className="text-2xl sm:text-3xl font-serif font-bold text-primary">{stat.value}</p>
              <p className="text-xs text-muted-foreground mt-1">{stat.label}</p>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
