import { useState, useRef } from "react";
import { Upload, Image as ImageIcon, File, Trash2, Download, Eye, Copy } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

interface MediaFile {
  id: string;
  name: string;
  url: string;
  type: string;
  size: number;
  created_at: string;
  metadata?: any;
}

export default function MediaManager() {
  const [files, setFiles] = useState<MediaFile[]>([]);
  const [uploading, setUploading] = useState(false);
  const [selectedFile, setSelectedFile] = useState<MediaFile | null>(null);
  const [previewOpen, setPreviewOpen] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const loadFiles = async () => {
    try {
      const { data, error } = await supabase.storage.from('media').list('', {
        limit: 100,
        offset: 0,
        sortBy: { column: 'created_at', order: 'desc' }
      });

      if (error) throw error;

      const filesWithUrls = await Promise.all(
        (data || []).map(async (file) => {
          const { data: { publicUrl } } = supabase.storage
            .from('media')
            .getPublicUrl(file.name);

          return {
            id: file.id,
            name: file.name,
            url: publicUrl,
            type: file.metadata?.mimetype || 'unknown',
            size: file.metadata?.size || 0,
            created_at: file.created_at,
            metadata: file.metadata
          } as MediaFile;
        })
      );

      setFiles(filesWithUrls);
    } catch (error) {
      toast({ title: "Error", description: "Failed to load files", variant: "destructive" });
    }
  };

  useState(() => {
    loadFiles();
  });

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = event.target.files;
    if (!selectedFiles || selectedFiles.length === 0) return;

    setUploading(true);
    const uploadPromises = Array.from(selectedFiles).map(async (file) => {
      const fileName = `${Date.now()}-${file.name}`;
      const { error } = await supabase.storage
        .from('media')
        .upload(fileName, file, {
          cacheControl: '3600',
          upsert: false,
          metadata: {
            mimetype: file.type,
            size: file.size,
            originalName: file.name
          }
        });

      if (error) throw error;
      return fileName;
    });

    try {
      await Promise.all(uploadPromises);
      toast({ title: "✓ Upload Complete", description: `${selectedFiles.length} files uploaded` });
      loadFiles();
    } catch (error) {
      toast({ title: "Error", description: "Failed to upload files", variant: "destructive" });
    } finally {
      setUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const handleDeleteFile = async (file: MediaFile) => {
    if (!confirm(`Are you sure you want to delete "${file.name}"?`)) return;

    try {
      const { error } = await supabase.storage
        .from('media')
        .remove([file.name]);

      if (error) throw error;

      toast({ title: "✓ File Deleted", description: `"${file.name}" has been deleted` });
      loadFiles();
    } catch (error) {
      toast({ title: "Error", description: "Failed to delete file", variant: "destructive" });
    }
  };

  const copyUrl = (url: string) => {
    navigator.clipboard.writeText(url);
    toast({ title: "✓ URL Copied", description: "File URL copied to clipboard" });
  };

  const downloadFile = (file: MediaFile) => {
    const link = document.createElement('a');
    link.href = file.url;
    link.download = file.name;
    link.click();
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const getFileIcon = (type: string) => {
    if (type.startsWith('image/')) return ImageIcon;
    return File;
  };

  const isImage = (type: string) => type.startsWith('image/');

  const filteredFiles = {
    all: files,
    images: files.filter(f => isImage(f.type)),
    documents: files.filter(f => !isImage(f.type))
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Media Library</h2>
          <p className="text-muted-foreground">Manage your images and files</p>
        </div>
        <div className="flex items-center gap-2">
          <input
            ref={fileInputRef}
            type="file"
            multiple
            onChange={handleFileUpload}
            className="hidden"
            accept="image/*,.pdf,.doc,.docx,.txt"
          />
          <Button
            onClick={() => fileInputRef.current?.click()}
            disabled={uploading}
          >
            <Upload className="w-4 h-4 mr-2" />
            {uploading ? 'Uploading...' : 'Upload Files'}
          </Button>
        </div>
      </div>

      <Tabs defaultValue="all" className="space-y-4">
        <TabsList>
          <TabsTrigger value="all">All Files ({files.length})</TabsTrigger>
          <TabsTrigger value="images">Images ({filteredFiles.images.length})</TabsTrigger>
          <TabsTrigger value="documents">Documents ({filteredFiles.documents.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="space-y-4">
          <FileGrid files={filteredFiles.all} />
        </TabsContent>

        <TabsContent value="images" className="space-y-4">
          <FileGrid files={filteredFiles.images} />
        </TabsContent>

        <TabsContent value="documents" className="space-y-4">
          <FileGrid files={filteredFiles.documents} />
        </TabsContent>
      </Tabs>

      {/* Preview Dialog */}
      <Dialog open={previewOpen} onOpenChange={setPreviewOpen}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>{selectedFile?.name}</DialogTitle>
          </DialogHeader>
          {selectedFile && (
            <div className="space-y-4">
              {isImage(selectedFile.type) ? (
                <img
                  src={selectedFile.url}
                  alt={selectedFile.name}
                  className="w-full h-auto max-h-96 object-contain rounded-lg"
                />
              ) : (
                <div className="flex items-center justify-center h-64 bg-muted rounded-lg">
                  <File className="w-16 h-16 text-muted-foreground" />
                </div>
              )}
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <Label>File Type</Label>
                  <p className="text-muted-foreground">{selectedFile.type}</p>
                </div>
                <div>
                  <Label>File Size</Label>
                  <p className="text-muted-foreground">{formatFileSize(selectedFile.size)}</p>
                </div>
                <div>
                  <Label>Uploaded</Label>
                  <p className="text-muted-foreground">
                    {new Date(selectedFile.created_at).toLocaleDateString()}
                  </p>
                </div>
                <div>
                  <Label>URL</Label>
                  <p className="text-muted-foreground truncate">{selectedFile.url}</p>
                </div>
              </div>
              <div className="flex gap-2">
                <Button onClick={() => copyUrl(selectedFile.url)} variant="outline">
                  <Copy className="w-4 h-4 mr-2" />
                  Copy URL
                </Button>
                <Button onClick={() => downloadFile(selectedFile)} variant="outline">
                  <Download className="w-4 h-4 mr-2" />
                  Download
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );

  function FileGrid({ files }: { files: MediaFile[] }) {
    if (files.length === 0) {
      return (
        <Card>
          <CardContent className="p-12 text-center">
            <ImageIcon className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
            <h3 className="text-lg font-semibold mb-2">No files yet</h3>
            <p className="text-muted-foreground mb-4">Upload your first files to get started</p>
            <Button onClick={() => fileInputRef.current?.click()}>
              <Upload className="w-4 h-4 mr-2" />
              Upload Files
            </Button>
          </CardContent>
        </Card>
      );
    }

    return (
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4">
        {files.map((file) => {
          const Icon = getFileIcon(file.type);
          return (
            <Card key={file.id} className="group cursor-pointer overflow-hidden">
              <CardContent className="p-0">
                <div
                  className="aspect-square bg-muted relative flex items-center justify-center"
                  onClick={() => {
                    setSelectedFile(file);
                    setPreviewOpen(true);
                  }}
                >
                  {isImage(file.type) ? (
                    <img
                      src={file.url}
                      alt={file.name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <Icon className="w-8 h-8 text-muted-foreground" />
                  )}
                  <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <Eye className="w-6 h-6 text-white" />
                  </div>
                </div>
                <div className="p-2">
                  <p className="text-xs font-medium truncate">{file.name}</p>
                  <p className="text-xs text-muted-foreground">{formatFileSize(file.size)}</p>
                  <div className="flex gap-1 mt-2">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={(e) => {
                        e.stopPropagation();
                        copyUrl(file.url);
                      }}
                      className="h-6 w-6 p-0"
                    >
                      <Copy className="w-3 h-3" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDeleteFile(file);
                      }}
                      className="h-6 w-6 p-0 text-destructive"
                    >
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    );
  }
}
