import { motion, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";
import portfolio1 from "@/assets/portfolio-1.jpg";
import portfolio2 from "@/assets/portfolio-2.jpg";
import portfolio3 from "@/assets/portfolio-3.jpg";
import { ExternalLink } from "lucide-react";

const PROPERTIES = [
  { img: portfolio1, title: "Seaview Penthouse", location: "Sliema", beds: "3 Bed", rating: "4.97" },
  { img: portfolio2, title: "Harbour Terrace", location: "Valletta", beds: "2 Bed", rating: "4.95" },
  { img: portfolio3, title: "Heritage Suite", location: "Mdina", beds: "1 Bed", rating: "4.98" },
];

export default function PortfolioSection() {
  const ref = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });
  const y = useTransform(scrollYProgress, [0, 1], [30, -30]);

  return (
    <section id="portfolio" ref={ref} className="min-h-screen flex items-center py-20 sm:py-28 bg-card/30">
      <div className="section-container w-full">
        <motion.div style={{ y }}>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <p className="micro-type text-primary mb-3">Portfolio</p>
            <h2 className="font-serif text-3xl sm:text-4xl font-semibold text-foreground">
              Properties we <span className="gold-text">manage</span>
            </h2>
          </motion.div>
        </motion.div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {PROPERTIES.map((p, i) => (
            <motion.a
              key={p.title}
              href="http://malta.staydirectly.com/"
              target="_blank"
              rel="noopener noreferrer"
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="group glass-surface rounded-lg overflow-hidden hover:border-primary/30 transition-colors cursor-pointer block"
            >
              <div className="aspect-[4/3] overflow-hidden relative">
                <img
                  src={p.img}
                  alt={p.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end justify-end p-4">
                  <ExternalLink size={18} className="text-primary" />
                </div>
              </div>
              <div className="p-5">
                <div className="flex items-center justify-between mb-1">
                  <h3 className="font-serif text-lg font-semibold text-foreground">{p.title}</h3>
                  <span className="text-sm font-medium text-primary">★ {p.rating}</span>
                </div>
                <p className="text-sm text-muted-foreground">{p.location} · {p.beds}</p>
              </div>
            </motion.a>
          ))}
        </div>

        <div className="text-center mt-12">
          <a
            href="http://malta.staydirectly.com/"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-8 py-3 text-sm font-semibold border border-border text-foreground rounded hover:border-primary hover:text-primary transition-colors"
          >
            View All Properties <ExternalLink size={14} />
          </a>
        </div>
      </div>
    </section>
  );
}
