import { describe, it, expect, vi, beforeEach } from "vitest";

// Mock Supabase
const mockSupabase = {
  from: vi.fn(() => ({
    insert: vi.fn().mockReturnThis(),
    select: vi.fn().mockReturnThis(),
    single: vi.fn().mockResolvedValue({
      data: {
        id: "test-id",
        filename: "test.jpg",
        url: "https://example.com/test.jpg",
        thumbnail_url: "https://example.com/test-thumb.jpg",
        size: 1024,
        mime_type: "image/jpeg",
        width: 100,
        height: 100,
        alt_text: "Test",
        metadata: {},
        created_at: "2024-01-01",
      },
      error: null,
    }),
  })),
  storage: {
    from: vi.fn(() => ({
      upload: vi.fn().mockResolvedValue({
        data: { path: "test.jpg" },
        error: null,
      }),
      getPublicUrl: vi.fn().mockReturnValue({
        data: { publicUrl: "https://example.com/test.jpg" },
      }),
    })),
  },
};

vi.mock("@/lib/supabase", () => ({
  supabase: mockSupabase,
}));

describe("MediaManager", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("uploads file successfully", async () => {
    const { MediaManager } = await import("./media-manager");
    const manager = new MediaManager();

    const file = new File(["test"], "test.jpg", { type: "image/jpeg" });

    const result = await manager.upload(file, {
      folder: "test",
      quality: 80,
    });

    expect(result).toBeDefined();
    expect(result.filename).toBe("test.jpg");
  });

  it("handles upload errors", async () => {
    const { MediaManager } = await import("./media-manager");
    const manager = new MediaManager();

    vi.spyOn(mockSupabase.storage.from(""), "upload").mockRejectedValueOnce(
      new Error("Upload failed"),
    );

    const file = new File(["test"], "test.jpg", { type: "image/jpeg" });

    await expect(
      manager.upload(file, { folder: "test" }),
    ).rejects.toThrow("Upload failed");
  });

  it("builds transformation string correctly", async () => {
    const { MediaManager } = await import("./media-manager");
    const manager = new MediaManager();

    const transformation = {
      width: 100,
      height: 100,
      crop: "fit" as const,
      quality: 80,
      format: "auto" as const,
    };

    const result = manager.buildTransformationString(transformation);
    expect(result).toBe("w_100,h_100,c_fit,q_80,f_auto");
  });
});