# 🔐 SECURITY REMEDIATION CHECKLIST

**Project:** Christiano Property Management CMS v2.0.0
**Priority Level:** CRITICAL
**Due Date:** IMMEDIATE
**Estimated Effort:** 40-60 hours

---

## ⚠️ TIER 1: CRITICAL - MUST FIX BEFORE PRODUCTION

### 1. 🔴 EXPOSED SECRETS REMEDIATION

**Task ID:** SEC-001
**Severity:** CRITICAL
**Status:** ⬜ NOT STARTED

#### Step 1: Immediate Actions (Within 24 hours)

- [ ] **Back up current .env file securely**
  ```bash
  # Save to secure location (NOT git)
  cp .env ~/.backup/.env.backup
  ```

- [ ] **Rotate ALL credentials in Supabase**
  - [ ] Login to Supabase dashboard
  - [ ] Navigate to Settings → API Keys
  - [ ] Regenerate: `anon` key
  - [ ] Regenerate: `service_role` key
  - [ ] Regenerate: JWT secret
  - [ ] Rotate database password
  - [ ] Update all connection strings

- [ ] **Remove .env from git history**
  ```bash
  # Install filter-repo if needed
  brew install git-filter-repo

  # Remove .env from all commits
  git filter-repo --invert-paths --path .env

  # Force push (be careful!)
  git push origin --force-with-lease --all
  ```

- [ ] **Verify .env is in .gitignore**
  ```bash
  grep ".env" .gitignore
  # Should show:
  # .env
  # .env.local
  # .env.*.local
  ```

#### Step 2: Environment Variable Setup (Immediate)

- [ ] **Create .env.example with placeholder values**
  ```env
  # DO NOT include real secrets here
  NEXT_PUBLIC_SUPABASE_ANON_KEY=your_anon_key_here
  NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY=your_publishable_key_here
  NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
  POSTGRES_USER=postgres
  POSTGRES_PASSWORD=your_password_here
  POSTGRES_HOST=db.your-project.supabase.co
  ```

- [ ] **Create .env.local with real credentials (local dev only)**
  ```bash
  # .env.local (NEVER commit, in .gitignore)
  # Add new rotated credentials here
  ```

- [ ] **Set up Vercel Environment Variables**
  - [ ] Go to Vercel Dashboard
  - [ ] Project Settings → Environment Variables
  - [ ] Add for Preview:
    - [ ] VITE_SUPABASE_URL
    - [ ] VITE_SUPABASE_PUBLISHABLE_KEY
  - [ ] Add for Production (separate from Preview):
    - [ ] All variables with production values

- [ ] **Verify no .env references in code**
  ```bash
  grep -r "import.meta.env" src/ | grep -v "VITE_"
  # Should find nothing or only valid VITE_ variables
  ```

#### Step 3: Verification

- [ ] Run security check
  ```bash
  # Check for hardcoded secrets
  git log --all --full-history -- .env
  # Should show removal in latest commit
  ```

- [ ] Confirm build works with environment variables
  ```bash
  bun run build
  # Should succeed without warnings about missing secrets
  ```

**Checklist Completion:** [ ] All items completed

---

### 2. 🔴 XSS VULNERABILITY FIX (dangerouslySetInnerHTML)

**Task ID:** SEC-002
**Severity:** CRITICAL
**Status:** ⬜ NOT STARTED
**Files Affected:** `src/pages/CmsPage.tsx` (lines 145, 195, 200)

#### Step 1: Install DOMPurify

- [ ] Install package
  ```bash
  bun add isomorphic-dompurify
  bun add -D @types/dompurify
  ```

#### Step 2: Create Sanitization Utility

- [ ] Create `src/utils/sanitize.ts`
  ```typescript
  import { sanitize } from 'isomorphic-dompurify';

  export function sanitizeHtml(html: string): string {
    return sanitize(html, {
      ALLOWED_TAGS: [
        'b', 'i', 'em', 'strong', 'p', 'br', 'ul', 'ol', 'li',
        'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
        'a', 'img', 'blockquote', 'code', 'pre', 'hr',
      ],
      ALLOWED_ATTR: ['href', 'src', 'alt', 'title', 'class'],
      ALLOW_DATA_ATTR: false,
    });
  }

  export function renderSafeHtml(html: string) {
    return <div dangerouslySetInnerHTML={{ __html: sanitizeHtml(html) }} />;
  }
  ```

#### Step 3: Update CmsPage Component

- [ ] Update `src/pages/CmsPage.tsx`

  ```typescript
  import { sanitizeHtml } from '@/utils/sanitize';

  // Replace all dangerouslySetInnerHTML instances:

  // Before:
  // <div dangerouslySetInnerHTML={{ __html: content.body }} />

  // After:
  // <div dangerouslySetInnerHTML={{ __html: sanitizeHtml(content.body) }} />
  ```

  **Specific lines to update:**
  - [ ] Line 145: `{content.body && (<div dangerouslySetInnerHTML={{ __html: sanitizeHtml(content.body) }} />)}`
  - [ ] Line 195: `{content.body && (<div dangerouslySetInnerHTML={{ __html: sanitizeHtml(content.body) }} />)}`
  - [ ] Line 200: `<div dangerouslySetInnerHTML={{ __html: sanitizeHtml(section.content) }} />`

#### Step 4: Add CSP Headers

- [ ] Create `public/headers.json` (for Vercel)
  ```json
  {
    "headers": [
      {
        "source": "/(.*)",
        "headers": [
          {
            "key": "Content-Security-Policy",
            "value": "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:; font-src 'self'; connect-src 'self' https://muwjzgujvpflbbvixmmz.supabase.co;"
          }
        ]
      }
    ]
  }
  ```

- [ ] Or configure in `vercel.json`:
  ```json
  {
    "headers": [
      {
        "source": "/(.*)",
        "headers": [
          {
            "key": "Content-Security-Policy",
            "value": "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:;"
          },
          {
            "key": "X-Content-Type-Options",
            "value": "nosniff"
          },
          {
            "key": "X-Frame-Options",
            "value": "DENY"
          }
        ]
      }
    ]
  }
  ```

#### Step 5: Testing

- [ ] Add unit test for sanitization
  ```typescript
  import { describe, it, expect } from 'vitest';
  import { sanitizeHtml } from '@/utils/sanitize';

  describe('sanitizeHtml', () => {
    it('should remove script tags', () => {
      const dirty = '<p>Hello <script>alert("XSS")</script></p>';
      const clean = sanitizeHtml(dirty);
      expect(clean).not.toContain('<script>');
    });

    it('should preserve safe HTML', () => {
      const safe = '<p>Hello <strong>World</strong></p>';
      const clean = sanitizeHtml(safe);
      expect(clean).toContain('<strong>');
    });

    it('should remove onclick handlers', () => {
      const dirty = '<p onclick="alert(\'XSS\')">Click me</p>';
      const clean = sanitizeHtml(dirty);
      expect(clean).not.toContain('onclick');
    });
  });
  ```

- [ ] Run security scan
  ```bash
  bun run lint:check
  # Should not flag dangerouslySetInnerHTML with sanitization
  ```

**Checklist Completion:** [ ] All items completed

---

### 3. 🔴 ADD ROLE-BASED AUTHORIZATION

**Task ID:** SEC-003
**Severity:** CRITICAL
**Status:** ⬜ NOT STARTED
**Files Affected:** `src/pages/Admin.tsx`

#### Step 1: Define User Types

- [ ] Create `src/types/auth.ts`
  ```typescript
  import type { Session } from '@supabase/supabase-js';

  export type UserRole = 'admin' | 'editor' | 'viewer' | 'guest';

  export interface AuthUser extends Session {
    user_role?: UserRole;
    permissions?: string[];
  }

  export interface UserProfile {
    id: string;
    email: string;
    role: UserRole;
    permissions: string[];
    created_at: string;
    updated_at: string;
  }

  export const ROLE_PERMISSIONS = {
    admin: [
      'pages:create',
      'pages:read',
      'pages:update',
      'pages:delete',
      'content:manage',
      'settings:manage',
      'users:manage',
    ],
    editor: [
      'pages:create',
      'pages:read',
      'pages:update',
      'content:manage',
    ],
    viewer: [
      'pages:read',
    ],
    guest: [],
  } as const;
  ```

#### Step 2: Create Auth Hook

- [ ] Create `src/hooks/use-auth-user.ts`
  ```typescript
  import { useEffect, useState } from 'react';
  import { supabase } from '@/integrations/supabase/client';
  import type { AuthUser, UserProfile } from '@/types/auth';

  export function useAuthUser() {
    const [user, setUser] = useState<AuthUser | null>(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<Error | null>(null);

    useEffect(() => {
      const checkUser = async () => {
        try {
          const { data: { user: authUser }, error: authError } = await supabase.auth.getUser();

          if (authError) {
            setError(authError);
            setUser(null);
            return;
          }

          if (!authUser) {
            setUser(null);
            return;
          }

          // Fetch user profile with role
          const { data: profile, error: profileError } = await supabase
            .from('user_profiles')
            .select('*')
            .eq('id', authUser.id)
            .single();

          if (profileError && profileError.code !== 'PGRST116') {
            setError(profileError);
            return;
          }

          setUser({
            ...authUser,
            user_role: profile?.role || 'viewer',
            permissions: profile?.permissions || [],
          });
        } catch (err) {
          setError(err instanceof Error ? err : new Error('Unknown error'));
        } finally {
          setLoading(false);
        }
      };

      checkUser();

      const { data: { subscription } } = supabase.auth.onAuthStateChange(
        async (_event, session) => {
          if (session?.user) {
            const { data: profile } = await supabase
              .from('user_profiles')
              .select('*')
              .eq('id', session.user.id)
              .single();

            setUser({
              ...session,
              user_role: profile?.role || 'viewer',
              permissions: profile?.permissions || [],
            });
          } else {
            setUser(null);
          }
        }
      );

      return () => subscription?.unsubscribe();
    }, []);

    return { user, loading, error };
  }

  export function useHasPermission(permission: string) {
    const { user } = useAuthUser();
    return user?.permissions?.includes(permission) ?? false;
  }

  export function useHasRole(role: string) {
    const { user } = useAuthUser();
    return user?.user_role === role;
  }
  ```

#### Step 3: Update Admin Page

- [ ] Update `src/pages/Admin.tsx`
  ```typescript
  import { useAuthUser } from '@/hooks/use-auth-user';
  import { AccessDenied } from '@/components/AccessDenied';

  export default function Admin() {
    const { user, loading } = useAuthUser();
    const [activeTab, setActiveTab] = useState<string>('dashboard');
    // ... other state

    if (loading) {
      return <LoadingScreen />;
    }

    if (!user) {
      return <AdminLogin />;
    }

    // ✅ NEW: Check for admin role
    if (user.user_role !== 'admin') {
      return <AccessDenied />;
    }

    return (
      // ... existing component
    );
  }
  ```

#### Step 4: Create Access Control Components

- [ ] Create `src/components/ProtectedRoute.tsx`
  ```typescript
  import { useAuthUser } from '@/hooks/use-auth-user';
  import { AccessDenied } from '@/components/AccessDenied';

  interface ProtectedRouteProps {
    requiredRole?: string;
    requiredPermission?: string;
    children: React.ReactNode;
    fallback?: React.ReactNode;
  }

  export function ProtectedRoute({
    requiredRole,
    requiredPermission,
    children,
    fallback,
  }: ProtectedRouteProps) {
    const { user } = useAuthUser();

    if (!user) {
      return fallback || <AccessDenied />;
    }

    if (requiredRole && user.user_role !== requiredRole) {
      return fallback || <AccessDenied />;
    }

    if (requiredPermission && !user.permissions?.includes(requiredPermission)) {
      return fallback || <AccessDenied />;
    }

    return <>{children}</>;
  }
  ```

#### Step 5: Create Access Denied Component

- [ ] Create `src/components/AccessDenied.tsx`
  ```typescript
  import { AlertTriangle, Home } from 'lucide-react';
  import { Button } from '@/components/ui/button';
  import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
  import { useNavigate } from 'react-router-dom';

  export function AccessDenied() {
    const navigate = useNavigate();

    return (
      <div className="min-h-screen flex items-center justify-center p-4 bg-background">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <div className="mx-auto w-16 h-16 rounded-full bg-amber-100 flex items-center justify-center mb-4">
              <AlertTriangle className="w-8 h-8 text-amber-600" />
            </div>
            <CardTitle className="text-2xl font-bold text-amber-600">
              Access Denied
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="text-center text-muted-foreground">
              <p>
                You don't have permission to access this page. Please contact your administrator
                if you believe this is an error.
              </p>
            </div>

            <div className="flex gap-3 justify-center">
              <Button
                onClick={() => navigate('/')}
                className="flex items-center gap-2"
              >
                <Home className="w-4 h-4" />
                Go Home
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }
  ```

**Checklist Completion:** [ ] All items completed

---

### 4. 🔴 IMPLEMENT SUPABASE ROW LEVEL SECURITY

**Task ID:** SEC-004
**Severity:** CRITICAL
**Status:** ⬜ NOT STARTED

#### Step 1: Enable RLS on All Tables

- [ ] Login to Supabase Dashboard
- [ ] Navigate to Database → Tables
- [ ] For each table: `cms_pages`, `cms_content`, `cms_settings`, `cms_navigation`:
  - [ ] Click on table name
  - [ ] Click "RLS Disabled" toggle to enable
  - [ ] Confirm alert

#### Step 2: Create RLS Policies

- [ ] Open SQL Editor in Supabase
- [ ] Run the following SQL:

  ```sql
  -- Check if RLS is enabled
  SELECT tablename, rowsecurity
  FROM pg_tables
  WHERE schemaname = 'public'
  ORDER BY tablename;

  -- Create function to check admin role
  CREATE OR REPLACE FUNCTION is_admin()
  RETURNS BOOLEAN AS $$
  BEGIN
    RETURN auth.jwt() ->> 'role' = 'admin' OR
           EXISTS (
             SELECT 1 FROM user_profiles
             WHERE id = auth.uid() AND role = 'admin'
           );
  END;
  $$ LANGUAGE plpgsql SECURITY DEFINER;

  -- CMS PAGES: Public can view published pages
  CREATE POLICY "Public can view published pages"
  ON cms_pages
  FOR SELECT
  USING (status = 'published' AND is_visible = true);

  -- CMS PAGES: Admin can manage all pages
  CREATE POLICY "Admin can manage all pages"
  ON cms_pages
  FOR ALL
  USING (is_admin());

  -- CMS CONTENT: Public can view visible content
  CREATE POLICY "Public can view visible content"
  ON cms_content
  FOR SELECT
  USING (is_visible = true);

  -- CMS CONTENT: Admin can manage content
  CREATE POLICY "Admin can manage content"
  ON cms_content
  FOR ALL
  USING (is_admin());

  -- CMS SETTINGS: Admin only
  CREATE POLICY "Admin can manage settings"
  ON cms_settings
  FOR ALL
  USING (is_admin());

  -- CMS NAVIGATION: Public can view active navigation
  CREATE POLICY "Public can view active navigation"
  ON cms_navigation
  FOR SELECT
  USING (is_active = true);

  -- CMS NAVIGATION: Admin can manage navigation
  CREATE POLICY "Admin can manage navigation"
  ON cms_navigation
  FOR ALL
  USING (is_admin());
  ```

#### Step 3: Verify RLS Policies

- [ ] Run the following to verify:
  ```sql
  SELECT
    schemaname,
    tablename,
    rowsecurity,
    (SELECT COUNT(*) FROM pg_policies WHERE pg_policies.tablename = pg_tables.tablename) as policy_count
  FROM pg_tables
  WHERE schemaname = 'public'
  ORDER BY tablename;
  ```

- [ ] Expected output: All tables should have `rowsecurity = true` and `policy_count > 0`

**Checklist Completion:** [ ] All items completed

---

## 🟠 TIER 2: HIGH - COMPLETE WITHIN 2-3 WEEKS

### 5. 🟠 INPUT VALIDATION WITH ZOD

**Task ID:** SEC-005
**Severity:** HIGH
**Status:** ⬜ NOT STARTED
**Estimated Effort:** 8 hours

- [ ] Create validation schemas in `src/schemas/`
- [ ] Implement form validation in all admin components
- [ ] Add server-side validation
- [ ] Write tests for all validators

---

### 6. 🟠 ERROR TRACKING INTEGRATION

**Task ID:** SEC-006
**Severity:** HIGH
**Status:** ⬜ NOT STARTED
**Estimated Effort:** 4 hours

```bash
bun add @sentry/react @sentry/tracing
```

```typescript
import * as Sentry from "@sentry/react";

Sentry.init({
  dsn: import.meta.env.VITE_SENTRY_DSN,
  environment: import.meta.env.MODE,
  tracesSampleRate: 1.0,
  integrations: [
    new Sentry.Replay({
      maskAllText: true,
      blockAllMedia: true,
    }),
  ],
  replaysSessionSampleRate: 0.1,
  replaysOnErrorSampleRate: 1.0,
});
```

---

### 7. 🟠 INCREASE TEST COVERAGE TO 80%

**Task ID:** SEC-007
**Severity:** HIGH
**Status:** ⬜ NOT STARTED
**Estimated Effort:** 16 hours

- [ ] Write unit tests for all hooks
- [ ] Write component tests for critical components
- [ ] Write integration tests for API calls
- [ ] Setup coverage reporting
- [ ] Target: 80% coverage minimum

---

## 🟡 TIER 3: MEDIUM - COMPLETE WITHIN 4-5 WEEKS

### 8. 🟡 ACCESSIBILITY COMPLIANCE (WCAG 2.1 AA)

**Task ID:** SEC-008
**Severity:** MEDIUM
**Status:** ⬜ NOT STARTED

- [ ] Add `alt` attributes to all images
- [ ] Add ARIA labels to interactive elements
- [ ] Fix color contrast ratios
- [ ] Add keyboard navigation support
- [ ] Test with screen readers

---

### 9. 🟡 RATE LIMITING

**Task ID:** SEC-009
**Severity:** MEDIUM
**Status:** ⬜ NOT STARTED

```bash
bun add express-rate-limit
```

---

## ✅ VERIFICATION CHECKLIST

Once all fixes are completed:

- [ ] No secrets in git history
- [ ] All XSS vulnerabilities patched
- [ ] Authorization checks implemented
- [ ] RLS policies active on database
- [ ] Test suite passes (80%+ coverage)
- [ ] Security audit passes
- [ ] Performance benchmarks met
- [ ] E2E tests pass
- [ ] No console errors in production build

---

**Last Updated:** February 13, 2026
**Owner:** Security Team
**Status:** PENDING IMPLEMENTATION
