# ✅ CODE FIXES READY TO APPLY

**These are production-ready code snippets ready to implement**

---

## 1. SANITIZE.TS - XSS PROTECTION UTILITY

**Create:** `src/utils/sanitize.ts`

```typescript
import { sanitize } from 'isomorphic-dompurify';

interface SanitizeOptions {
  allowedTags?: string[];
  allowedAttributes?: string[];
}

const DEFAULT_OPTIONS: SanitizeOptions = {
  allowedTags: [
    'b', 'i', 'em', 'strong', 'p', 'br', 'ul', 'ol', 'li',
    'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
    'a', 'img', 'blockquote', 'code', 'pre', 'hr',
    'div', 'span', 'section', 'article', 'header', 'footer',
  ],
  allowedAttributes: ['href', 'src', 'alt', 'title', 'class', 'id'],
};

/**
 * Sanitize HTML to prevent XSS attacks
 * @param html - Raw HTML string
 * @param options - Sanitization options
 * @returns Sanitized HTML string
 */
export function sanitizeHtml(html: string, options: SanitizeOptions = DEFAULT_OPTIONS): string {
  if (!html || typeof html !== 'string') {
    return '';
  }

  return sanitize(html, {
    ALLOWED_TAGS: options.allowedTags || DEFAULT_OPTIONS.allowedTags,
    ALLOWED_ATTR: options.allowedAttributes || DEFAULT_OPTIONS.allowedAttributes,
    ALLOW_DATA_ATTR: false,
    KEEP_CONTENT: true,
  });
}

/**
 * Safely render HTML in React
 * @param html - HTML string to render
 * @returns React element with sanitized content
 */
export function renderSafeHtml(html: string): React.ReactElement {
  const sanitizedHtml = sanitizeHtml(html);
  return <div dangerouslySetInnerHTML={{ __html: sanitizedHtml }} />;
}

export default sanitizeHtml;
```

**Update package.json:**
```bash
bun add isomorphic-dompurify
```

---

## 2. AUTH TYPES - USER ROLE & PERMISSIONS

**Create:** `src/types/auth.ts`

```typescript
import type { Session } from '@supabase/supabase-js';

/**
 * User role definitions
 */
export type UserRole = 'admin' | 'editor' | 'viewer' | 'guest';

/**
 * Extended auth session with user profile data
 */
export interface AuthUser {
  id: string;
  email: string;
  session: Session | null;
  role: UserRole;
  permissions: string[];
  last_sign_in_at?: string;
}

/**
 * User profile from database
 */
export interface UserProfile {
  id: string;
  email: string;
  role: UserRole;
  permissions: string[];
  created_at: string;
  updated_at: string;
  is_active: boolean;
}

/**
 * Role-based permissions mapping
 */
export const ROLE_PERMISSIONS: Record<UserRole, string[]> = {
  admin: [
    'pages:create',
    'pages:read',
    'pages:update',
    'pages:delete',
    'content:create',
    'content:read',
    'content:update',
    'content:delete',
    'settings:read',
    'settings:update',
    'settings:delete',
    'media:manage',
    'users:read',
    'users:manage',
  ],
  editor: [
    'pages:create',
    'pages:read',
    'pages:update',
    'content:create',
    'content:read',
    'content:update',
    'media:manage',
  ],
  viewer: [
    'pages:read',
    'content:read',
  ],
  guest: [],
};

/**
 * Check if role has permission
 */
export function hasPermission(role: UserRole, permission: string): boolean {
  return ROLE_PERMISSIONS[role]?.includes(permission) ?? false;
}
```

---

## 3. USE-AUTH-USER.TS - AUTHENTICATION HOOK

**Create:** `src/hooks/use-auth-user.ts`

```typescript
import { useCallback, useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import type { AuthUser, UserRole } from '@/types/auth';

const DEFAULT_USER: AuthUser = {
  id: '',
  email: '',
  session: null,
  role: 'guest',
  permissions: [],
};

/**
 * Hook for getting current authenticated user with role and permissions
 */
export function useAuthUser() {
  const [user, setUser] = useState<AuthUser>(DEFAULT_USER);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  const fetchUserProfile = useCallback(async (userId: string) => {
    try {
      const { data, error: fetchError } = await supabase
        .from('user_profiles')
        .select('*')
        .eq('id', userId)
        .single();

      if (fetchError && fetchError.code !== 'PGRST116') {
        console.warn('Failed to fetch user profile:', fetchError);
        return { role: 'viewer' as UserRole, permissions: [] };
      }

      return {
        role: data?.role ?? 'viewer' as UserRole,
        permissions: data?.permissions ?? [],
      };
    } catch (err) {
      console.error('Error fetching user profile:', err);
      return { role: 'viewer' as UserRole, permissions: [] };
    }
  }, []);

  useEffect(() => {
    let mounted = true;

    const checkAuthStatus = async () => {
      try {
        const { data: { session }, error: authError } = await supabase.auth.getSession();

        if (!mounted) return;

        if (authError) {
          setError(authError);
          setUser(DEFAULT_USER);
          setLoading(false);
          return;
        }

        if (!session?.user) {
          setUser(DEFAULT_USER);
          setLoading(false);
          return;
        }

        const profile = await fetchUserProfile(session.user.id);

        setUser({
          id: session.user.id,
          email: session.user.email || '',
          session,
          role: profile.role,
          permissions: profile.permissions,
          last_sign_in_at: session.user.last_sign_in_at,
        });

        setError(null);
      } catch (err) {
        if (mounted) {
          setError(err instanceof Error ? err : new Error('Unknown error'));
        }
      } finally {
        if (mounted) {
          setLoading(false);
        }
      }
    };

    checkAuthStatus();

    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        if (!mounted) return;

        if (session?.user) {
          const profile = await fetchUserProfile(session.user.id);
          setUser({
            id: session.user.id,
            email: session.user.email || '',
            session,
            role: profile.role,
            permissions: profile.permissions,
          });
          setError(null);
        } else {
          setUser(DEFAULT_USER);
        }
      }
    );

    return () => {
      mounted = false;
      subscription?.unsubscribe();
    };
  }, [fetchUserProfile]);

  return { user, loading, error };
}

/**
 * Hook to check if user has specific permission
 */
export function useHasPermission(permission: string) {
  const { user } = useAuthUser();
  return user.permissions?.includes(permission) ?? false;
}

/**
 * Hook to check if user has specific role
 */
export function useHasRole(role: UserRole) {
  const { user } = useAuthUser();
  return user.role === role;
}

/**
 * Hook to check if user is admin
 */
export function useIsAdmin() {
  const { user } = useAuthUser();
  return user.role === 'admin';
}
```

---

## 4. PROTECTED-ROUTE.TSX - ROUTE PROTECTION

**Create:** `src/components/ProtectedRoute.tsx`

```typescript
import { ReactNode } from 'react';
import { useAuthUser } from '@/hooks/use-auth-user';
import { AccessDenied } from '@/components/AccessDenied';

interface ProtectedRouteProps {
  children: ReactNode;
  requiredRole?: string;
  requiredPermission?: string | string[];
  fallback?: ReactNode;
}

/**
 * Component to protect routes based on user role/permissions
 */
export function ProtectedRoute({
  children,
  requiredRole,
  requiredPermission,
  fallback,
}: ProtectedRouteProps) {
  const { user, loading } = useAuthUser();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
      </div>
    );
  }

  if (!user.id) {
    return fallback || <AccessDenied />;
  }

  if (requiredRole && user.role !== requiredRole) {
    return fallback || <AccessDenied />;
  }

  if (requiredPermission) {
    const permissions = Array.isArray(requiredPermission)
      ? requiredPermission
      : [requiredPermission];

    const hasPermission = permissions.some((p) => user.permissions?.includes(p));
    if (!hasPermission) {
      return fallback || <AccessDenied />;
    }
  }

  return <>{children}</>;
}
```

---

## 5. ACCESS-DENIED.TSX - ACCESS DENIED COMPONENT

**Create:** `src/components/AccessDenied.tsx`

```typescript
import { AlertTriangle, Home, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useNavigate } from 'react-router-dom';

interface AccessDeniedProps {
  message?: string;
  title?: string;
}

export function AccessDenied({
  message = "You don't have permission to access this page. Please contact your administrator if you believe this is an error.",
  title = 'Access Denied',
}: AccessDeniedProps) {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-background">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="mx-auto w-16 h-16 rounded-full bg-amber-100 dark:bg-amber-900 flex items-center justify-center mb-4">
            <AlertTriangle className="w-8 h-8 text-amber-600 dark:text-amber-400" />
          </div>
          <CardTitle className="text-2xl font-bold text-amber-600 dark:text-amber-400">
            {title}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="text-center text-muted-foreground">
            <p>{message}</p>
          </div>

          <div className="flex gap-3 justify-center">
            <Button
              onClick={() => navigate(-1)}
              variant="outline"
              className="flex items-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              Go Back
            </Button>
            <Button
              onClick={() => navigate('/')}
              className="flex items-center gap-2"
            >
              <Home className="w-4 h-4" />
              Go Home
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
```

---

## 6. UPDATED ADMIN.TSX - WITH AUTHORIZATION

**File:** `src/pages/Admin.tsx`

Replace the entire file with:

```typescript
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useCmsContent, useCmsSettings, useUpdateCmsContent, useUpdateCmsSetting } from '@/hooks/use-cms';
import { useAuthUser } from '@/hooks/use-auth-user';
import { AccessDenied } from '@/components/AccessDenied';
import type { Json } from '@/integrations/supabase/types';
import { useToast } from '@/hooks/use-toast';
import AdminLogin from '@/components/admin/AdminLogin';
import AdminSidebar from '@/components/admin/AdminSidebar';
import SectionEditor from '@/components/admin/SectionEditor';
import SettingsEditor from '@/components/admin/SettingsEditor';
import IntegrationsPanel from '@/components/admin/IntegrationsPanel';
import AdminDashboard from '@/components/admin/AdminDashboard';
import PageManager from '@/components/admin/PageManager';
import MediaManager from '@/components/admin/MediaManager';

export default function Admin() {
  const { user, loading: authLoading } = useAuthUser();
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [activeSection, setActiveSection] = useState<string>('hero');
  const { toast } = useToast();

  const { data: sections, isLoading: sectionsLoading } = useCmsContent();
  const { data: settings, isLoading: settingsLoading } = useCmsSettings();
  const updateContent = useUpdateCmsContent();
  const updateSetting = useUpdateCmsSetting();

  const handleSaveContent = async (sectionKey: string, content: Json, isVisible?: boolean) => {
    try {
      await updateContent.mutateAsync({ sectionKey, content, isVisible });
      toast({ title: '✓ Saved', description: `${sectionKey} updated successfully` });
    } catch (error) {
      console.error('Error saving content:', error);
      toast({ title: 'Error', description: 'Failed to save', variant: 'destructive' });
    }
  };

  const handleSaveSetting = async (settingKey: string, value: Json) => {
    try {
      await updateSetting.mutateAsync({ key: settingKey, value });
      toast({ title: '✓ Saved', description: 'Setting updated' });
    } catch (error) {
      console.error('Error saving setting:', error);
      toast({ title: 'Error', description: 'Failed to save setting', variant: 'destructive' });
    }
  };

  // Loading state
  if (authLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-3" />
          <p className="text-sm text-muted-foreground">Loading admin...</p>
        </div>
      </div>
    );
  }

  // Not authenticated
  if (!user.id) {
    return <AdminLogin />;
  }

  // Not authorized (must be admin)
  if (user.role !== 'admin') {
    return (
      <AccessDenied
        title="Admin Access Required"
        message="This area is restricted to administrators only. Please contact your administrator if you need access."
      />
    );
  }

  return (
    <div className="min-h-screen bg-background flex">
      <AdminSidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        activeSection={activeSection}
        setActiveSection={setActiveSection}
        sections={sections || []}
        onLogout={() => supabase.auth.signOut()}
      />
      <main className="flex-1 p-6 lg:p-8 overflow-y-auto">
        <div className="max-w-4xl mx-auto">
          {activeTab === 'dashboard' && (
            <AdminDashboard
              sections={sections || []}
              settings={settings || []}
              onNavigate={(tab, section) => {
                setActiveTab(tab);
                if (section) setActiveSection(section);
              }}
            />
          )}
          {activeTab === 'media' && <MediaManager />}
          {activeTab === 'pages' && <PageManager />}
          {activeTab === 'sections' && (
            <SectionEditor
              sections={sections || []}
              activeSection={activeSection}
              isLoading={sectionsLoading}
              onSave={handleSaveContent}
              isSaving={updateContent.isPending}
            />
          )}
          {activeTab === 'settings' && (
            <SettingsEditor
              settings={settings || []}
              isLoading={settingsLoading}
              onSave={handleSaveSetting}
              isSaving={updateSetting.isPending}
            />
          )}
          {activeTab === 'integrations' && (
            <IntegrationsPanel
              settings={settings || []}
              onSaveSetting={handleSaveSetting}
            />
          )}
        </div>
      </main>
    </div>
  );
}
```

---

## 7. UPDATED CMSPAGE.TSX - WITH XSS PROTECTION

**File:** `src/pages/CmsPage.tsx`

Replace the entire file with:

```typescript
import { useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useCmsPage } from '@/hooks/use-cms';
import { sanitizeHtml } from '@/utils/sanitize';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Home } from 'lucide-react';

export default function CmsPage() {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();
  const { data: page, isLoading, error } = useCmsPage(slug || '');

  useEffect(() => {
    if (page?.meta_title) {
      document.title = page.meta_title;
    } else if (page?.title) {
      document.title = `${page.title} | Christiano Vincenti Property Management`;
    }

    if (page?.meta_description) {
      const metaDescription = document.querySelector('meta[name="description"]');
      if (metaDescription) {
        metaDescription.setAttribute('content', page.meta_description);
      } else {
        const newMeta = document.createElement('meta');
        newMeta.setAttribute('name', 'description');
        newMeta.setAttribute('content', page.meta_description);
        document.head.appendChild(newMeta);
      }
    }
  }, [page]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="flex items-center justify-center h-64">
          <div
            className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"
            role="status"
            aria-label="Loading page"
          >
            <span className="sr-only">Loading...</span>
          </div>
        </div>
      </div>
    );
  }

  if (error || !page) {
    return (
      <div className="min-h-screen bg-background">
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <h1 className="text-2xl font-bold mb-4">Page Not Found</h1>
            <p className="text-muted-foreground mb-6">The page you're looking for doesn't exist.</p>
            <Button onClick={() => navigate('/')}>
              <Home className="w-4 h-4 mr-2" />
              Back to Home
            </Button>
          </div>
        </div>
      </div>
    );
  }

  if (page.status !== 'published') {
    return (
      <div className="min-h-screen bg-background">
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <h1 className="text-2xl font-bold mb-4">Page Not Available</h1>
            <p className="text-muted-foreground mb-6">This page is not yet published.</p>
            <Button onClick={() => navigate('/')}>
              <Home className="w-4 h-4 mr-2" />
              Back to Home
            </Button>
          </div>
        </div>
      </div>
    );
  }

  const renderPageContent = () => {
    const content = page.content as any;

    switch (page.template) {
      case 'landing':
        return (
          <div className="space-y-16">
            {content.hero && (
              <section className="relative min-h-screen flex items-center justify-center bg-gradient-to-br from-primary/10 to-secondary/10">
                <div className="text-center max-w-4xl mx-auto px-6">
                  <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-bold text-foreground leading-tight mb-6">
                    {content.hero.headline}
                  </h1>
                  <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
                    {content.hero.description}
                  </p>
                  {content.hero.cta && (
                    <Button size="lg" className="text-lg px-8 py-4">
                      {content.hero.cta.text}
                    </Button>
                  )}
                </div>
              </section>
            )}

            {content.features && (
              <section className="py-16">
                <div className="max-w-6xl mx-auto px-6">
                  <h2 className="font-serif text-3xl font-bold text-center mb-12">
                    {content.features.title}
                  </h2>
                  <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                    {content.features.items?.map((feature: any, index: number) => (
                      <div key={index} className="text-center">
                        <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                          <span className="text-2xl">{feature.icon}</span>
                        </div>
                        <h3 className="text-xl font-semibold mb-3">{feature.title}</h3>
                        <p className="text-muted-foreground">{feature.description}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </section>
            )}
          </div>
        );

      case 'blog':
        return (
          <article className="max-w-4xl mx-auto px-6 py-12">
            <header className="mb-8">
              <h1 className="font-serif text-4xl font-bold text-foreground leading-tight mb-4">
                {page.title}
              </h1>
              {content.author && (
                <div className="flex items-center gap-4 text-muted-foreground">
                  <span>By {content.author}</span>
                  {content.publishedDate && (
                    <span>• {new Date(content.publishedDate).toLocaleDateString()}</span>
                  )}
                </div>
              )}
            </header>

            <div className="prose prose-lg max-w-none">
              {content.body && (
                // ✅ FIXED: Using sanitization
                <div dangerouslySetInnerHTML={{ __html: sanitizeHtml(content.body) }} />
              )}
            </div>
          </article>
        );

      case 'portfolio':
        return (
          <div className="max-w-7xl mx-auto px-6 py-12">
            <header className="text-center mb-12">
              <h1 className="font-serif text-4xl font-bold text-foreground leading-tight mb-4">
                {page.title}
              </h1>
              {content.subtitle && (
                <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                  {content.subtitle}
                </p>
              )}
            </header>

            {content.projects && (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                {content.projects.map((project: any, index: number) => (
                  <div key={index} className="group cursor-pointer">
                    <div className="aspect-video bg-secondary rounded-lg mb-4 overflow-hidden">
                      {project.image && (
                        <img
                          src={project.image}
                          alt={project.title}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                      )}
                    </div>
                    <h3 className="text-xl font-semibold mb-2">{project.title}</h3>
                    <p className="text-muted-foreground">{project.description}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        );

      default:
        return (
          <div className="max-w-4xl mx-auto px-6 py-12">
            <h1 className="font-serif text-4xl font-bold text-foreground leading-tight mb-8">
              {page.title}
            </h1>
            <div className="prose prose-lg max-w-none">
              {content.body && (
                // ✅ FIXED: Using sanitization
                <div dangerouslySetInnerHTML={{ __html: sanitizeHtml(content.body) }} />
              )}
              {content.sections?.map((section: any, index: number) => (
                <section key={index} className="mb-12">
                  <h2 className="text-2xl font-semibold mb-4">{section.title}</h2>
                  {/* ✅ FIXED: Using sanitization */}
                  <div dangerouslySetInnerHTML={{ __html: sanitizeHtml(section.content) }} />
                </section>
              ))}
            </div>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar onOpenWizard={() => {}} />
      <main>{renderPageContent()}</main>
      <Footer />
    </div>
  );
}
```

---

## 8. SUPABASE RLS POLICIES - SQL

**Execute in Supabase SQL Editor:**

```sql
-- Enable RLS on all tables
ALTER TABLE cms_pages ENABLE ROW LEVEL SECURITY;
ALTER TABLE cms_content ENABLE ROW LEVEL SECURITY;
ALTER TABLE cms_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE cms_navigation ENABLE ROW LEVEL SECURITY;

-- Create helper function to check admin role
CREATE OR REPLACE FUNCTION is_admin()
RETURNS BOOLEAN AS $$
BEGIN
  RETURN auth.jwt() ->> 'role' = 'admin' OR
         EXISTS (
           SELECT 1 FROM user_profiles
           WHERE id = auth.uid() AND role = 'admin'
         );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- CMS PAGES POLICIES
CREATE POLICY "Public can view published pages"
ON cms_pages
FOR SELECT
USING (status = 'published');

CREATE POLICY "Admin can manage all pages"
ON cms_pages
FOR ALL
USING (is_admin());

-- CMS CONTENT POLICIES
CREATE POLICY "Public can view visible content"
ON cms_content
FOR SELECT
USING (is_visible = true);

CREATE POLICY "Admin can manage content"
ON cms_content
FOR ALL
USING (is_admin());

-- CMS SETTINGS POLICIES (Admin only!)
CREATE POLICY "Admin can manage settings"
ON cms_settings
FOR ALL
USING (is_admin());

-- CMS NAVIGATION POLICIES
CREATE POLICY "Public can view active navigation"
ON cms_navigation
FOR SELECT
USING (is_active = true);

CREATE POLICY "Admin can manage navigation"
ON cms_navigation
FOR ALL
USING (is_admin());

-- Verify policies
SELECT table_name, policy_name
FROM information_schema.role_table_grants
WHERE table_schema='public'
ORDER BY table_name;
```

---

## IMPLEMENTATION ORDER

1. ✅ Create `src/utils/sanitize.ts` (15 min)
2. ✅ Create `src/types/auth.ts` (10 min)
3. ✅ Create `src/hooks/use-auth-user.ts` (20 min)
4. ✅ Create `src/components/ProtectedRoute.tsx` (10 min)
5. ✅ Create `src/components/AccessDenied.tsx` (15 min)
6. ✅ Update `src/pages/Admin.tsx` (15 min)
7. ✅ Update `src/pages/CmsPage.tsx` (15 min)
8. ✅ Run Supabase SQL for RLS policies (10 min)
9. ✅ Test all changes (30 min)
10. ✅ Run linting and type checking (5 min)

**Total Estimated Time:** ~2.5 hours

---

**Ready to implement?** Contact the security team for approval.
