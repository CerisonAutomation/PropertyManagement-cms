import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";

interface StickyCTAProps {
  onOpenWizard: () => void;
}

export default function StickyCTA({ onOpenWizard }: StickyCTAProps) {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const onScroll = () => setVisible(window.scrollY > 600);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          initial={{ y: 100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 100, opacity: 0 }}
          className="fixed bottom-0 left-0 right-0 z-40 p-4 md:hidden glass-surface border-t border-border"
        >
          <button
            onClick={onOpenWizard}
            className="w-full py-3.5 text-sm font-semibold bg-primary text-primary-foreground rounded hover:bg-gold-light transition-colors"
          >
            Get Your Free Assessment
          </button>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
