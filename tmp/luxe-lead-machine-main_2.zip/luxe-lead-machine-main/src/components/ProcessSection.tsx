import { motion } from "framer-motion";
import { ClipboardCheck, Camera, Rocket } from "lucide-react";

const STEPS = [
  {
    icon: ClipboardCheck,
    step: "01",
    title: "Free Assessment",
    desc: "Tell us about your property and goals. We'll analyse your potential income and recommend the right plan.",
  },
  {
    icon: Camera,
    step: "02",
    title: "We Set You Up",
    desc: "Professional photography, listing optimisation, pricing strategy, and MTA licensing support — all handled.",
  },
  {
    icon: Rocket,
    step: "03",
    title: "You Earn More",
    desc: "We manage bookings, guests, cleaning, and maintenance. You receive monthly payouts and transparent reports.",
  },
];

export default function ProcessSection() {
  return (
    <section id="process" className="py-20 sm:py-28">
      <div className="section-container">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <p className="micro-type text-primary mb-3">How It Works</p>
          <h2 className="font-serif text-3xl sm:text-4xl font-semibold text-foreground">
            Three steps to <span className="gold-text">stress-free</span> income
          </h2>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {STEPS.map((s, i) => (
            <motion.div
              key={s.step}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.15, duration: 0.5 }}
              className="glass-surface rounded-lg p-8 relative group hover:border-primary/30 transition-colors"
            >
              <span className="absolute top-6 right-6 font-serif text-5xl font-bold text-border/50 group-hover:text-primary/20 transition-colors">
                {s.step}
              </span>
              <div className="w-12 h-12 rounded-lg bg-secondary flex items-center justify-center mb-6">
                <s.icon size={22} className="text-primary" />
              </div>
              <h3 className="font-serif text-xl font-semibold text-foreground mb-3">{s.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{s.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
