import { motion } from "framer-motion";
import portfolio1 from "@/assets/portfolio-1.jpg";
import portfolio2 from "@/assets/portfolio-2.jpg";
import portfolio3 from "@/assets/portfolio-3.jpg";

const PROPERTIES = [
  { img: portfolio1, title: "Seaview Penthouse", location: "Sliema", beds: "3 Bed", rating: "4.97" },
  { img: portfolio2, title: "Harbour Terrace", location: "Valletta", beds: "2 Bed", rating: "4.95" },
  { img: portfolio3, title: "Heritage Suite", location: "Mdina", beds: "1 Bed", rating: "4.98" },
];

export default function PortfolioSection() {
  return (
    <section id="portfolio" className="py-20 sm:py-28 bg-card/30">
      <div className="section-container">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <p className="micro-type text-primary mb-3">Portfolio</p>
          <h2 className="font-serif text-3xl sm:text-4xl font-semibold text-foreground">
            Properties we <span className="gold-text">manage</span>
          </h2>
        </motion.div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {PROPERTIES.map((p, i) => (
            <motion.div
              key={p.title}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="group glass-surface rounded-lg overflow-hidden hover:border-primary/30 transition-colors"
            >
              <div className="aspect-[4/3] overflow-hidden">
                <img
                  src={p.img}
                  alt={p.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  loading="lazy"
                />
              </div>
              <div className="p-5">
                <div className="flex items-center justify-between mb-1">
                  <h3 className="font-serif text-lg font-semibold text-foreground">{p.title}</h3>
                  <span className="text-sm font-medium text-primary">★ {p.rating}</span>
                </div>
                <p className="text-sm text-muted-foreground">{p.location} · {p.beds}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
