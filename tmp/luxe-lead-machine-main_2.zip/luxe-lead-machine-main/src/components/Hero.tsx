import { motion } from "framer-motion";
import heroBg from "@/assets/hero-bg.jpg";

interface HeroProps {
  onOpenWizard: () => void;
}

export default function Hero({ onOpenWizard }: HeroProps) {
  return (
    <section className="relative min-h-screen flex items-end pb-20 sm:pb-28 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0">
        <img src={heroBg} alt="Luxury Malta villa with infinity pool overlooking the Mediterranean" className="w-full h-full object-cover" />
        <div className="absolute inset-0" style={{ background: "var(--gradient-hero-overlay)" }} />
      </div>

      <div className="section-container relative z-10 w-full">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: "easeOut" }}
          className="max-w-2xl"
        >
          <p className="micro-type text-primary mb-4">Malta's Premier Property Partner</p>
          <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-semibold text-foreground leading-[1.1] mb-6">
            Maximise your rental income,{" "}
            <span className="gold-text">effortlessly.</span>
          </h1>
          <p className="text-lg sm:text-xl text-muted-foreground mb-8 max-w-lg leading-relaxed">
            Full-service short-let management across Malta & Gozo. We handle everything — you earn more.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <button
              onClick={onOpenWizard}
              className="px-8 py-4 text-base font-semibold bg-primary text-primary-foreground rounded hover:bg-gold-light transition-all hover:shadow-lg"
            >
              Get Your Free Assessment
            </button>
            <a
              href="#process"
              className="px-8 py-4 text-base font-medium text-foreground border border-border rounded hover:border-primary hover:text-primary transition-colors text-center"
            >
              How It Works
            </a>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
