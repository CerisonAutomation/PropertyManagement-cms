export const MALTA_LOCALITIES = [
  "Attard", "Balzan", "Birgu (Vittoriosa)", "Birkirkara", "Birżebbuġa",
  "Bormla (Cospicua)", "Dingli", "Fgura", "Floriana", "Fontana (Gozo)",
  "Għajnsielem (Gozo)", "Għarb (Gozo)", "Għargħur", "Għasri (Gozo)",
  "Għaxaq", "Gudja", "Gżira", "Ħamrun", "Iklin", "Isla (Senglea)",
  "Kalkara", "Kerċem (Gozo)", "Kirkop", "Lija", "Luqa", "Marsa",
  "Marsaskala", "Marsaxlokk", "Mdina", "Mellieħa", "Mġarr",
  "Mġarr (Gozo)", "Mosta", "Mqabba", "Msida", "Mtarfa", "Munxar (Gozo)",
  "Nadur (Gozo)", "Naxxar", "Paola", "Pembroke", "Pietà", "Qala (Gozo)",
  "Qormi", "Qrendi", "Rabat", "Rabat (Gozo / Victoria)",
  "Safi", "San Ġiljan (St Julian's)", "San Ġwann", "San Lawrenz (Gozo)",
  "San Pawl il-Baħar (St Paul's Bay)", "Sannat (Gozo)", "Santa Luċija",
  "Santa Venera", "Siġġiewi", "Sliema", "Swieqi", "Ta' Xbiex",
  "Tarxien", "Valletta", "Xagħra (Gozo)", "Xewkija (Gozo)",
  "Xgħajra", "Żabbar", "Żebbuġ", "Żebbuġ (Gozo)", "Żejtun",
  "Żurrieq", "Buġibba", "Paceville", "Portomaso", "Tigne Point",
  "Smart City", "Madliena"
];

export const PROPERTY_TYPES = [
  "Apartment", "Penthouse", "Maisonette", "Townhouse", "Villa",
  "Farmhouse", "Palazzo", "Studio"
];

export const BEDROOM_OPTIONS = ["Studio", "1", "2", "3", "4", "5+"];
export const SLEEPS_OPTIONS = ["1-2", "3-4", "5-6", "7-8", "9-10", "11+"];
