export interface WizardData {
  // Step 0 - Choice
  status: "not_listed" | "already_listed" | "switching" | "";
  listingUrl?: string;
  currentManager?: string;
  // Step 1 - Property
  locality: string;
  propertyType: string;
  bedrooms: string;
  sleeps: string;
  // Step 2 - Goals
  timeline: string;
  goal: string;
  handsOff: boolean;
  licenceReady: boolean;
  upgradeBudget: string;
  // Step 3 - Contact
  name: string;
  email: string;
  phone: string;
  preferredContact: string;
  consent: boolean;
}

export const INITIAL_WIZARD_DATA: WizardData = {
  status: "",
  locality: "",
  propertyType: "",
  bedrooms: "",
  sleeps: "",
  timeline: "",
  goal: "",
  handsOff: false,
  licenceReady: false,
  upgradeBudget: "",
  name: "",
  email: "",
  phone: "",
  preferredContact: "whatsapp",
  consent: false,
};

export type LeadTier = "A" | "B" | "C";
export type RecommendedPlan = "Essentials" | "Complete";

export function computeTier(data: WizardData): LeadTier {
  const isAsap = data.timeline === "asap" || data.timeline === "2-6weeks";
  const isSwitching = data.status === "switching";
  const isHandsOff = data.handsOff;
  const highBudget = data.upgradeBudget === "3k-5k" || data.upgradeBudget === "5k+";
  const alreadyListed = data.status === "already_listed";

  if (isAsap && (isHandsOff || isSwitching) && (highBudget || alreadyListed)) return "A";
  if (isAsap || isHandsOff || isSwitching) return "B";
  return "C";
}

export function computePlan(data: WizardData): RecommendedPlan {
  if (data.handsOff || data.status === "switching" || data.goal === "direct_booking") return "Complete";
  return "Essentials";
}

const CPM_CONFIG = {
  webhook: "",
  whatsappNumber: "35679790202",
  calendlyUrl: "",
  ga4Id: "",
};

function generateSessionId(): string {
  return crypto.randomUUID?.() || Math.random().toString(36).substring(2);
}

function getAttribution() {
  const params = new URLSearchParams(window.location.search);
  return {
    utm_source: params.get("utm_source") || "",
    utm_medium: params.get("utm_medium") || "",
    utm_campaign: params.get("utm_campaign") || "",
    referrer: document.referrer,
    landing_page: window.location.href,
    session_id: generateSessionId(),
    timestamp: new Date().toISOString(),
  };
}

export async function submitLead(data: WizardData): Promise<"webhook" | "whatsapp" | "mailto"> {
  const tier = computeTier(data);
  const plan = computePlan(data);
  const attribution = getAttribution();
  const payload = { ...data, lead_tier: tier, recommended_plan: plan, ...attribution };

  // Try webhook
  if (CPM_CONFIG.webhook) {
    try {
      const res = await fetch(CPM_CONFIG.webhook, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      if (res.ok) return "webhook";
    } catch { /* fall through */ }
  }

  // WhatsApp fallback
  const msg = encodeURIComponent(
    `New lead from ${data.name}\n` +
    `Status: ${data.status}\n` +
    `Property: ${data.propertyType} in ${data.locality}, ${data.bedrooms} bed, sleeps ${data.sleeps}\n` +
    `Timeline: ${data.timeline}, Goal: ${data.goal}\n` +
    `Tier: ${tier}, Plan: ${plan}\n` +
    `Email: ${data.email}, Phone: ${data.phone}`
  );
  window.open(`https://wa.me/${CPM_CONFIG.whatsappNumber}?text=${msg}`, "_blank");
  return "whatsapp";
}

export function saveDraft(data: WizardData) {
  try { localStorage.setItem("cpm_draft", JSON.stringify(data)); } catch {}
}

export function loadDraft(): WizardData | null {
  try {
    const raw = localStorage.getItem("cpm_draft");
    return raw ? JSON.parse(raw) : null;
  } catch { return null; }
}

export function clearDraft() {
  try { localStorage.removeItem("cpm_draft"); } catch {}
}
