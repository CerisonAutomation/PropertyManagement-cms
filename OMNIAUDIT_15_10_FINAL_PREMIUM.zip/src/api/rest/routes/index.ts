import { Router } from 'express';
import { authRouter } from './auth';
import { pagesRouter } from './pages';
import { blogRouter } from './blog';
import { propertiesRouter } from './properties';
import { mediaRouter } from './media';
import { searchRouter } from './search';
import { healthRouter } from './health';

const router = Router();

// Mount all API routes
router.use('/auth', authRouter);
router.use('/pages', pagesRouter);
router.use('/blog-posts', blogRouter);
router.use('/properties', propertiesRouter);
router.use('/media', mediaRouter);
router.use('/search', searchRouter);
router.use('/health', healthRouter);

export default router;
