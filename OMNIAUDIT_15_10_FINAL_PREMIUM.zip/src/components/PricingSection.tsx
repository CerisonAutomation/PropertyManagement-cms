import { motion, useScroll, useTransform, useSpring } from "framer-motion";
import { useRef } from "react";
import { Check, Sparkles, Shield, Star, ArrowRight } from "lucide-react";

interface PricingSectionProps {
  onOpenWizard: () => void;
}

const PLANS = [
  {
    name: "Essentials",
    price: "15%",
    subtitle: "of booking revenue",
    desc: "Perfect for owners who want professional listing management with hands-on involvement.",
    icon: Shield,
    features: [
      "Professional photography",
      "Multi-platform listing",
      "Dynamic pricing",
      "Guest communication",
      "Monthly reporting",
      "MTA licence guidance",
    ],
    highlighted: false,
  },
  {
    name: "Complete",
    price: "20%",
    subtitle: "of booking revenue",
    desc: "Full hands-off management. We handle everything so you don't have to lift a finger.",
    icon: Star,
    features: [
      "Everything in Essentials",
      "Cleaning coordination",
      "Maintenance at cost",
      "Linen & amenities",
      "Welcome amenities included",
      "Guest property manual",
      "Direct booking website",
      "Owner dashboard access",
      "Priority 24hr support",
      "Quarterly strategy review",
    ],
    highlighted: true,
  },
];

const ADDONS = [
  { service: "Professional Photoshoot", price: "On quotation" },
  { service: "Annual Deep Clean", price: "On quotation" },
  { service: "MTA Licensing", price: "€150 + authority fees" },
  { service: "Procurement & Setup Works", price: "€25/hr + VAT" },
  { service: "Mail & Bills Handling", price: "€10/month" },
  { service: "Interior Design", price: "On quotation" },
];

export default function PricingSection({ onOpenWizard }: PricingSectionProps) {
  const containerRef = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start end", "end start"]
  });

  const y = useTransform(scrollYProgress, [0, 1], [50, -50]);
  const opacity = useTransform(scrollYProgress, [0, 0.3, 0.7, 1], [0, 1, 1, 0]);
  const scale = useTransform(scrollYProgress, [0, 0.3], [0.95, 1]);
  const smoothProgress = useSpring(scrollYProgress, { stiffness: 100, damping: 30 });

  return (
    <section
      id="pricing"
      ref={containerRef}
      className="relative min-h-screen flex items-center py-20 sm:py-28 overflow-hidden"
    >
      {/* Frozen animated background */}
      <div className="absolute inset-0 pointer-events-none">
        <motion.div
          className="absolute inset-0 opacity-30"
          style={{
            background: `radial-gradient(ellipse at 50% 0%, hsl(var(--luxury-gold) / 0.15) 0%, transparent 60%)`,
            y: useTransform(scrollYProgress, [0, 1], [0, -100])
          }}
        />
        {/* Floating particles */}
        {[...Array(6)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-2 h-2 rounded-full bg-primary/20"
            initial={{
              x: `${20 + i * 15}%`,
              y: `${30 + (i % 3) * 20}%`
            }}
            animate={{
              y: [null, `${20 + (i % 4) * 15}%`, `${30 + (i % 3) * 20}%`]
            }}
            transition={{
              duration: 8 + i * 2,
              repeat: Infinity,
              ease: "easeInOut",
              delay: i * 0.5
            }}
          />
        ))}
      </div>

      <div className="section-container w-full relative z-10">
        <motion.div style={{ y, opacity, scale }}>
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.6, ease: "easeOut" }}
            className="text-center mb-16"
          >
            <motion.div
              initial={{ scale: 0 }}
              whileInView={{ scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
              className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4"
            >
              <Sparkles size={14} />
              <span>Transparent Pricing</span>
            </motion.div>

            <h2 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-semibold text-foreground">
              Simple, <span className="gold-text">transparent</span> pricing
            </h2>
            <p className="text-muted-foreground mt-4 max-w-md mx-auto text-lg">
              No setup fees. No hidden costs. You only pay when you earn.
            </p>
          </motion.div>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {PLANS.map((plan, i) => (
            <motion.div
              key={plan.name}
              initial={{ opacity: 0, x: i === 0 ? -50 : 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ delay: i * 0.2, duration: 0.5, type: "spring" }}
              whileHover={{ y: -8, transition: { duration: 0.2 } }}
              className={`relative glass-surface rounded-2xl p-8 lg:p-10 ${
                plan.highlighted
                  ? "border-primary/50 shadow-[0_0_60px_-15px_hsl(var(--luxury-gold)_/_0.3)] lg:scale-105 lg:z-10"
                  : "border-border/50"
              }`}
            >
              {plan.highlighted && (
                <motion.span
                  initial={{ scale: 0, opacity: 0 }}
                  whileInView={{ scale: 1, opacity: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.3, type: "spring" }}
                  className="absolute -top-4 left-1/2 -translate-x-1/2 px-5 py-1.5 bg-gradient-to-r from-primary to-[#c9a227] text-primary-foreground text-xs font-bold rounded-full shadow-lg"
                >
                  Most Popular
                </motion.span>
              )}

              <div className="flex items-center gap-3 mb-4">
                <div className={`p-2.5 rounded-xl ${plan.highlighted ? 'bg-primary/20' : 'bg-secondary'}`}>
                  <plan.icon size={24} className={plan.highlighted ? 'text-primary' : 'text-muted-foreground'} />
                </div>
                <h3 className="font-serif text-2xl lg:text-3xl font-semibold text-foreground">{plan.name}</h3>
              </div>

              <div className="flex items-baseline gap-2 mb-2">
                <motion.span
                  className="text-5xl lg:text-6xl font-bold bg-gradient-to-r from-primary to-[#c9a227] bg-clip-text text-transparent"
                  initial={{ scale: 0.8 }}
                  whileInView={{ scale: 1 }}
                  viewport={{ once: true }}
                >
                  {plan.price}
                </motion.span>
                <span className="text-muted-foreground">{plan.subtitle}</span>
              </div>
              <p className="text-muted-foreground mb-8 text-base">{plan.desc}</p>

              <ul className="space-y-3 mb-8">
                {plan.features.map((f, idx) => (
                  <motion.li
                    key={f}
                    className="flex items-center gap-3 text-foreground"
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: idx * 0.05 }}
                  >
                    <motion.div
                      initial={{ scale: 0 }}
                      whileInView={{ scale: 1 }}
                      viewport={{ once: true }}
                      transition={{ delay: idx * 0.05 + 0.2, type: "spring" }}
                      className={`w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 ${
                        plan.highlighted ? 'bg-primary' : 'bg-secondary'
                      }`}
                    >
                      <Check size={12} className={plan.highlighted ? 'text-primary-foreground' : 'text-muted-foreground'} />
                    </motion.div>
                    {f}
                  </motion.li>
                ))}
              </ul>

              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={onOpenWizard}
                className={`w-full py-4 text-base font-semibold rounded-xl transition-all flex items-center justify-center gap-2 group ${
                  plan.highlighted
                    ? "bg-primary text-primary-foreground hover:bg-gold-light shadow-lg shadow-primary/25"
                    : "border-2 border-border text-foreground hover:border-primary hover:text-primary"
                }`}
              >
                Get Started
                <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
              </motion.button>
            </motion.div>
          ))}
        </div>

        {/* Add-on services with enhanced styling */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6 }}
          className="mt-20 max-w-4xl mx-auto"
        >
          <div className="text-center mb-8">
            <h3 className="font-serif text-2xl font-semibold text-foreground mb-2">
              Available on both plans
            </h3>
            <p className="text-muted-foreground">Charged separately • Custom quotations available</p>
          </div>

          <div className="glass-surface rounded-2xl overflow-hidden border border-border/30">
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 divide-y sm:divide-y-0 sm:divide-x divide-border/30">
              {ADDONS.map((a, idx) => (
                <motion.div
                  key={a.service}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: idx * 0.1 }}
                  className="p-5 hover:bg-secondary/20 transition-colors"
                >
                  <p className="text-foreground font-medium text-sm mb-1">{a.service}</p>
                  <p className="text-primary font-bold">{a.price}</p>
                </motion.div>
              ))}
            </div>
          </div>

          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="text-xs text-muted-foreground text-center mt-6 leading-relaxed"
          >
            Net Room Revenue is calculated on gross rental income, excluding platform commissions,
            VAT, cleaning fees, damage deposits, and optional extras. All agreements governed by Malta law.
          </motion.p>
        </motion.div>

        {/* Progress indicator */}
        <motion.div
          className="fixed bottom-8 left-1/2 -translate-x-1/2 w-32 h-1 bg-secondary rounded-full overflow-hidden z-50 lg:hidden"
          style={{ opacity: scrollYProgress }}
        >
          <motion.div
            className="h-full bg-primary"
            style={{ width: smoothProgress }}
          />
        </motion.div>
      </div>
    </section>
  );
}
