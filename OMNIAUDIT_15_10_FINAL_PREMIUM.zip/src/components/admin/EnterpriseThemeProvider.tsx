import React from 'react';
import { EnterpriseThemeProvider } from '@/lib/theme-provider';

interface Props {
  children: React.ReactNode;
}

export default function EnterpriseThemeProviderWrapper({ children }: Props) {
  return <EnterpriseThemeProvider>{children}</EnterpriseThemeProvider>;
}
