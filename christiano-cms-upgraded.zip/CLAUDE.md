# 🚀 CLAUDE - COMPREHENSIVE ENTERPRISE BEST PRACTICES GUIDE

## 🎯 EXECUTIVE SUMMARY

This guide extracts the **ABSOLUTE #1 BEST PRACTICES** from the world's top enterprise applications, compiled for building **production-ready, scalable, secure** systems.

---

## 📚 TABLE OF CONTENTS

1. [React 18 Performance Optimization](#-react-18-performance-optimization)
2. [Supabase Enterprise Patterns](#-supabase-enterprise-patterns)
3. [TypeScript Strict Mode Best Practices](#-typescript-strict-mode-best-practices)
4. [Playwright E2E Testing Patterns](#-playwright-e2e-testing-patterns)
5. [Modern React 18 Architecture](#-modern-react-18-architecture)
6. [Security & Authentication](#-security--authentication)
7. [State Management](#-state-management)
8. [Database Design](#-database-design)
9. [CI/CD Pipeline](#-cicd-pipeline)
10. [Error Handling & Monitoring](#-error-handling--monitoring)

---

## ⚡ React 18 Performance Optimization

### #1 Best Practice: Component Optimization

```typescript
// ✅ USE: memo with proper comparison
const ExpensiveComponent = memo(({ data, onUpdate }) => {
  const processedData = useMemo(() =>
    data.map(item => transformItem(item)),
    [data]
  );

  const handler = useCallback((id: string) => {
    onUpdate(id);
  }, [onUpdate]);

  return <div>{processedData.map(item => <Item key={item.id} {...item} onClick={handler} />)}</div>;
}, (prevProps, nextProps) => {
  return prevProps.data === nextProps.data && prevProps.onUpdate === nextProps.onUpdate;
});

// ❌ AVOID: Unnecessary re-renders
const BadComponent = ({ data }) => {
  return <div>{data.map(item => <Item key={item.id} {...item} />)}</div>;
};
```

### #1 Best Practice: Suspense & Lazy Loading

```typescript
// ✅ USE: Route-based code splitting
const AdminDashboard = lazy(() => import('./pages/AdminDashboard'));
const PropertiesPage = lazy(() => import('./pages/PropertiesPage'));

// ✅ USE: Suspense boundaries
<Suspense fallback={<PageLoader />}>
  <Routes>
    <Route path="/admin" element={<AdminDashboard />} />
    <Route path="/properties" element={<PropertiesPage />} />
  </Routes>
</Suspense>
```

### #1 Best Practice: Virtual Scrolling for Large Lists

```typescript
// ✅ USE: react-window for 10k+ items
import { FixedSizeList as List } from 'react-window';

const VirtualizedList = ({ items }) => {
  const Row = ({ index, style }) => (
    <div style={style}>
      <ItemComponent item={items[index]} />
    </div>
  );

  return (
    <List
      height={600}
      itemCount={items.length}
      itemSize={50}
      width="100%"
    >
      {Row}
    </List>
  );
};
```

---

## 🗄️ Supabase Enterprise Patterns

### #1 Best Practice: Row Level Security (RLS)

```sql
-- ✅ ALWAYS enable RLS on all tables
ALTER TABLE properties ENABLE ROW LEVEL SECURITY;

-- ✅ Use specific policies, not blanket policies
CREATE POLICY "Users can view own properties"
ON properties FOR SELECT
USING (auth.uid() = owner_id);

CREATE POLICY "Users can update own properties"
ON properties FOR UPDATE
USING (auth.uid() = owner_id)
WITH CHECK (auth.uid() = owner_id);

-- ✅ Use functions for complex logic
CREATE OR REPLACE FUNCTION update_property_status()
RETURNS TRIGGER AS $$
BEGIN
  -- Complex business logic here
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;
```

### #1 Best Practice: Real-time Subscriptions

```typescript
// ✅ USE: Typed real-time subscriptions
const usePropertyRealtime = (propertyId: string) => {
  const [property, setProperty] = useState<Property | null>(null);

  useEffect(() => {
    const subscription = supabase
      .channel(`property:${propertyId}`)
      .on('postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'properties', filter: `id=eq.${propertyId}` },
        (payload) => setProperty(payload.new as Property)
      )
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, [propertyId]);

  return property;
};
```

### #1 Best Practice: Database Functions & Triggers

```sql
-- ✅ Use functions for business logic
CREATE OR REPLACE FUNCTION calculate_property_rating(property_uuid UUID)
RETURNS NUMERIC AS $$
DECLARE
  avg_rating NUMERIC;
BEGIN
  SELECT AVG(rating::NUMERIC) INTO avg_rating
  FROM reviews
  WHERE property_id = property_uuid;

  UPDATE properties
  SET rating = COALESCE(avg_rating, 0)
  WHERE id = property_uuid;

  RETURN avg_rating;
END;
$$ LANGUAGE plpgsql;

-- ✅ Auto-trigger on review insert
CREATE TRIGGER trigger_calculate_rating
  AFTER INSERT ON reviews
  FOR EACH ROW
  EXECUTE FUNCTION calculate_property_rating(NEW.property_id);
```

---

## 🔷 TypeScript Strict Mode Best Practices

### #1 Best Practice: Strict Type Definitions

```typescript
// ✅ USE: Branded types for IDs
type UserId = string & { readonly brand: unique symbol };
type PropertyId = string & { readonly brand: unique symbol };

const createUserId = (id: string): UserId => id as UserId;
const createPropertyId = (id: string): PropertyId => id as PropertyId;

// ✅ USE: Discriminated unions for state
type LoadingState =
  | { status: 'idle' }
  | { status: 'loading' }
  | { status: 'success'; data: Property }
  | { status: 'error'; error: Error };

// ✅ USE: Utility types
type PropertyFormData = Omit<Property, 'id' | 'created_at' | 'updated_at'>;
type PropertyUpdate = Partial<Pick<Property, 'name' | 'description' | 'price'>>;
```

### #1 Best Practice: Generic Constraints

```typescript
// ✅ USE: Proper generics with constraints
function createApiCall<T extends BaseEntity>(endpoint: string): Promise<T> {
  return fetch(endpoint).then(res => res.json());
}

// ✅ USE: Generic hooks
function useApi<T>(url: string, options?: RequestInit) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<Error | null>(null);

  useEffect(() => {
    fetch(url, options)
      .then(res => res.json())
      .then(setData)
      .catch(setError);
  }, [url]);

  return { data, error };
}
```

---

## 🎭 Playwright E2E Testing Patterns

### #1 Best Practice: Page Object Model

```typescript
// ✅ USE: Page Object Model
export class AdminDashboardPage {
  constructor(private page: Page) {}

  async navigateToSection(section: string) {
    await this.page.click(`[data-testid="nav-${section}"]`);
  }

  async editProperty(propertyId: string) {
    await this.page.click(`[data-testid="property-${propertyId}"]`);
    await this.page.click('[data-testid="edit-button"]');
  }

  async fillPropertyForm(data: PropertyFormData) {
    await this.page.fill('[name="name"]', data.name);
    await this.page.fill('[name="description"]', data.description);
    await this.page.fill('[name="price"]', data.price.toString());
  }
}

// ✅ USE: In tests
test('should update property', async ({ page }) => {
  const adminPage = new AdminDashboardPage(page);
  await adminPage.login('admin@example.com', 'password');
  await adminPage.editProperty('123');
  await adminPage.fillPropertyForm({
    name: 'Updated Property',
    description: 'Updated description',
    price: 1000,
  });
});
```

### #1 Best Practice: Custom Test Matchers

```typescript
// ✅ USE: Custom matchers for business logic
export const expect = baseExpect.extend({
  toHavePropertyValue(received: Property, property: keyof Property, value: any) {
    const pass = received[property] === value;
    if (pass) {
      return {
        message: () => `expected ${property} not to equal ${value}`,
        pass: true,
      };
    }
    return {
      message: () => `expected ${property} to equal ${value}, but received ${received[property]}`,
      pass: false,
    };
  },
});
```

---

## 🏗️ Modern React 18 Architecture

### #1 Best Practice: Compound Components

```typescript
// ✅ USE: Compound component pattern
interface AccordionContextType {
  openItems: Set<string>;
  toggleItem: (id: string) => void;
}

const AccordionContext = createContext<AccordionContextType | null>(null);

const Accordion = ({ children, multiple = false, ...props }) => {
  const [openItems, setOpenItems] = useState<Set<string>>(new Set());

  const toggleItem = useCallback((id: string) => {
    setOpenItems(prev => {
      const newSet = new Set(prev);
      if (newSet.has(id)) {
        newSet.delete(id);
      } else {
        if (!multiple) newSet.clear();
        newSet.add(id);
      }
      return newSet;
    });
  }, [multiple]);

  return (
    <AccordionContext.Provider value={{ openItems, toggleItem }}>
      <div {...props}>{children}</div>
    </AccordionContext.Provider>
  );
};

const AccordionItem = ({ id, children }) => {
  const context = useContext(AccordionContext);
  if (!context) throw new Error('AccordionItem must be used within Accordion');

  const isOpen = context.openItems.has(id);

  return (
    <div data-open={isOpen}>
      {children(isOpen)}
    </div>
  );
};

// Usage
<Accordion multiple>
  <AccordionItem id="item1">
    {(isOpen) => (
      <>
        <button onClick={() => context.toggleItem('item1')}>
          {isOpen ? 'Collapse' : 'Expand'}
        </button>
        <div>{/* Content */}</div>
      </>
    )}
  </AccordionItem>
</Accordion>
```

### #1 Best Practice: Custom Hooks Composition

```typescript
// ✅ USE: Composable custom hooks
function usePropertySearch() {
  const [filters, setFilters] = useState<SearchFilters>({});
  const [sort, setSort] = useState<SortOption>('price_asc');

  const { data, loading, error } = useApi<Property[]>(
    buildSearchUrl(filters, sort)
  );

  return { data, loading, error, filters, setFilters, sort, setSort };
}

function useFavorites() {
  const [favorites, setFavorites] = useState<PropertyId[]>([]);

  const toggleFavorite = useCallback((id: PropertyId) => {
    setFavorites(prev =>
      prev.includes(id)
        ? prev.filter(fav => fav !== id)
        : [...prev, id]
    );
  }, []);

  const isFavorite = useCallback((id: PropertyId) =>
    favorites.includes(id), [favorites]);

  return { favorites, toggleFavorite, isFavorite };
}

// Compose hooks
function PropertyListPage() {
  const search = usePropertySearch();
  const favorites = useFavorites();

  const properties = useMemo(() =>
    search.data?.filter(p =>
      favorites.isFavorite(p.id) ? true : true
    ), [search.data, favorites]);

  return (
    <div>
      {/* UI */}
    </div>
  );
}
```

---

## 🔐 Security & Authentication

### #1 Best Practice: JWT with Refresh Tokens

```typescript
// ✅ USE: Secure token storage
const authService = {
  async login(credentials: LoginCredentials) {
    const { access_token, refresh_token, expires_in } =
      await supabase.auth.signInWithPassword(credentials);

    // Store refresh token in httpOnly cookie (handled by backend)
    // Store access token in memory only
    setAccessToken(access_token);

    // Schedule token refresh
    this.scheduleRefresh(expires_in);
  },

  async refreshAccessToken() {
    const { data, error } = await supabase.auth.refreshSession();
    if (error) throw error;

    setAccessToken(data.access_token!);
    this.scheduleRefresh(data.expires_in!);
  },

  scheduleRefresh(expiresIn: number) {
    setTimeout(() => this.refreshAccessToken(),
      (expiresIn - 60) * 1000 // Refresh 1 minute before expiry
    );
  },
};
```

### #1 Best Practice: Role-Based Access Control (RBAC)

```typescript
// ✅ USE: Permission-based rendering
const usePermissions = () => {
  const { user } = useAuth();

  const permissions = useMemo(() => {
    if (!user) return new Set<string>();

    return new Set(
      user.user_metadata?.permissions || []
    );
  }, [user]);

  const hasPermission = useCallback((permission: string) =>
    permissions.has(permission), [permissions]);

  return { hasPermission, permissions };
};

// Component
const PropertyEditor = () => {
  const { hasPermission } = usePermissions();

  if (!hasPermission('properties:edit')) {
    return <AccessDenied />;
  }

  return <Editor />;
};
```

---

## 🎛️ State Management

### #1 Best Practice: Zustand with Middleware

```typescript
// ✅ USE: Zustand with persist and immer
import { create } from 'zustand';
import { persist, subscribeWithSelector } from 'zustand/middleware';
import { immer } from 'zustand/middleware/immer';

interface PropertyStore {
  properties: Property[];
  selectedProperty: Property | null;
  filters: SearchFilters;

  addProperty: (property: Property) => void;
  updateProperty: (id: string, updates: Partial<Property>) => void;
  selectProperty: (property: Property | null) => void;
  setFilters: (filters: SearchFilters) => void;
}

const usePropertyStore = create<PropertyStore>()(
  persist(
    subscribeWithSelector(
      immer((set) => ({
        properties: [],
        selectedProperty: null,
        filters: {},

        addProperty: (property) => set((state) => {
          state.properties.push(property);
        }),

        updateProperty: (id, updates) => set((state) => {
          const index = state.properties.findIndex(p => p.id === id);
          if (index !== -1) {
            Object.assign(state.properties[index], updates);
          }
        }),

        selectProperty: (property) => set({ selectedProperty: property }),
        setFilters: (filters) => set({ filters }),
      }))
    ),
    {
      name: 'property-store',
      partialize: (state) => ({
        filters: state.filters
      }),
    }
  )
);
```

---

## 💾 Database Design

### #1 Best Practice: Normalized Schema

```sql
-- ✅ USE: Proper normalization
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email VARCHAR UNIQUE NOT NULL,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE properties (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id UUID REFERENCES users(id) ON DELETE CASCADE,
  name VARCHAR NOT NULL,
  description TEXT,
  price DECIMAL(10,2),
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE bookings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  property_id UUID REFERENCES properties(id) ON DELETE CASCADE,
  guest_id UUID REFERENCES users(id) ON DELETE CASCADE,
  check_in DATE NOT NULL,
  check_out DATE NOT NULL,
  status VARCHAR DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT NOW(),

  CONSTRAINT valid_dates CHECK (check_out > check_in)
);

-- ✅ USE: Indexes for performance
CREATE INDEX idx_properties_owner ON properties(owner_id);
CREATE INDEX idx_bookings_property ON bookings(property_id);
CREATE INDEX idx_bookings_dates ON bookings(check_in, check_out);
```

### #1 Best Practice: Database Functions

```sql
-- ✅ USE: Business logic in functions
CREATE OR REPLACE FUNCTION get_available_properties(
  check_in_date DATE,
  check_out_date DATE,
  min_price DECIMAL DEFAULT 0,
  max_price DECIMAL DEFAULT 999999
)
RETURNS TABLE (
  id UUID,
  name VARCHAR,
  description TEXT,
  price DECIMAL
) AS $$
BEGIN
  RETURN QUERY
  SELECT p.id, p.name, p.description, p.price
  FROM properties p
  WHERE p.price BETWEEN min_price AND max_price
    AND NOT EXISTS (
      SELECT 1 FROM bookings b
      WHERE b.property_id = p.id
        AND b.status = 'confirmed'
        AND (
          (b.check_in <= check_in_date AND b.check_out > check_in_date) OR
          (b.check_in < check_out_date AND b.check_out >= check_out_date) OR
          (b.check_in >= check_in_date AND b.check_out <= check_out_date)
        )
    );
END;
$$ LANGUAGE plpgsql;
```

---

## 🚀 CI/CD Pipeline

### #1 Best Practice: GitHub Actions Workflow

```yaml
# ✅ USE: Multi-stage pipeline
name: CI/CD Pipeline

on:
  push:
    branches: [main, develop]
  pull_request:
    branches: [main]

jobs:
  lint:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: 20
      - run: bun install
      - run: bun run lint

  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: 20
      - run: bun install
      - run: bun run test:unit
      - run: bun run test:e2e

  build:
    needs: [lint, test]
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: 20
      - run: bun install
      - run: bun run build

  deploy:
    needs: [build]
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/main'
    steps:
      - uses: actions/checkout@v4
      - uses: amondnet/vercel-action@v25
        with:
          vercel-token: ${{ secrets.VERCEL_TOKEN }}
          vercel-org-id: ${{ secrets.ORG_ID }}
          vercel-project-id: ${{ secrets.PROJECT_ID }}
```

---

## 📊 Error Handling & Monitoring

### #1 Best Practice: Structured Error Handling

```typescript
// ✅ USE: Custom error classes
class AppError extends Error {
  constructor(
    message: string,
    public code: string,
    public statusCode: number = 500,
    public isOperational = true
  ) {
    super(message);
    Object.setPrototypeOf(this, AppError.prototype);
  }
}

class ValidationError extends AppError {
  constructor(message: string, public field: string) {
    super(message, 'VALIDATION_ERROR', 400);
  }
}

// ✅ USE: Error boundary with reporting
class ErrorBoundary extends Component {
  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    // Report to monitoring service
    if (isProduction) {
      reportError(error, {
        context: errorInfo,
        userId: this.props.user?.id,
        timestamp: new Date().toISOString(),
      });
    }
  }
}
```

### #1 Best Practice: Performance Monitoring

```typescript
// ✅ USE: Web Vitals monitoring
import { getCLS, getFID, getFCP, getLCP, getTTFB } from 'web-vitals';

const sendToAnalytics = (metric: any) => {
  // Send to your analytics service
  supabase.from('performance_metrics').insert({
    metric_name: metric.name,
    metric_value: metric.value,
    page_path: window.location.pathname,
    session_id: getSessionId(),
  });
};

getCLS(sendToAnalytics);
getFID(sendToAnalytics);
getFCP(sendToAnalytics);
getLCP(sendToAnalytics);
getTTFB(sendToAnalytics);
```

---

## 🎯 SUMMARY

### The #1 Rules (Non-Negotiable):

1. **ALWAYS use TypeScript strict mode**
2. **ALWAYS implement RLS on Supabase**
3. **ALWAYS use Playwright for E2E testing**
4. **ALWAYS memoize expensive React components**
5. **ALWAYS use error boundaries**
6. **ALWAYS implement proper auth flows**
7. **ALWAYS use CI/CD pipeline**
8. **ALWAYS monitor performance**
9. **ALWAYS write tests (unit + e2e)**
10. **ALWAYS follow security best practices**

---

## 📖 Additional Resources

- [React 18 Documentation](https://react.dev)
- [Supabase Documentation](https://supabase.com/docs)
- [TypeScript Handbook](https://www.typescriptlang.org/docs)
- [Playwright Documentation](https://playwright.dev)
- [Biome Documentation](https://biomejs.dev)

---

**Built with ❤️ for Enterprise Excellence**