export const MALTA_LOCALITIES = [
  "Attard", "Balzan", "Birgu", "Birkirkara", "Birżebbuġa", "Bormla",
  "Dingli", "Fgura", "Floriana", "Fontana", "Għajnsielem", "Għarb",
  "Għargħur", "Għasri", "Għaxaq", "Gudja", "Gżira", "Ħamrun",
  "Iklin", "Isla", "Kalkara", "Kerċem", "Kirkop", "Lija", "Luqa",
  "Marsa", "Marsaskala", "Marsaxlokk", "Mdina", "Mellieħa", "Mġarr",
  "Mosta", "Mqabba", "Msida", "Mtarfa", "Munxar", "Nadur", "Naxxar",
  "Paola", "Pembroke", "Pietà", "Qala", "Qormi", "Qrendi",
  "Rabat", "Safi", "San Ġiljan", "San Ġwann", "San Lawrenz",
  "San Pawl il-Baħar", "Sannat", "Santa Luċija", "Santa Venera",
  "Siġġiewi", "Sliema", "Swieqi", "Ta' Xbiex", "Tarxien",
  "Valletta", "Xagħra", "Xewkija", "Xgħajra", "Żabbar",
  "Żebbuġ (Gozo)", "Żebbuġ (Malta)", "Żejtun", "Żurrieq",
];

export const PROPERTY_TYPES = ["Apartment", "Penthouse", "Townhouse", "Villa", "Farmhouse", "Maisonette"];
export const BEDROOM_OPTIONS = ["Studio", "1", "2", "3", "4+"];
export const SLEEPS_OPTIONS = ["1–2", "3–4", "5–6", "7–8", "9+"];
