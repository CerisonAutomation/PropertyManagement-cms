import { motion, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";
import { Check } from "lucide-react";

interface PricingSectionProps {
  onOpenWizard: () => void;
}

const PLANS = [
  {
    name: "Essentials",
    price: "15%",
    subtitle: "of booking revenue",
    desc: "Perfect for owners who want professional listing management with hands-on involvement.",
    features: [
      "Professional photography",
      "Multi-platform listing",
      "Dynamic pricing",
      "Guest communication",
      "Monthly reporting",
      "MTA licence guidance",
    ],
    highlighted: false,
  },
  {
    name: "Complete",
    price: "20%",
    subtitle: "of booking revenue",
    desc: "Full hands-off management. We handle everything so you don't have to lift a finger.",
    features: [
      "Everything in Essentials",
      "Cleaning coordination",
      "Maintenance at cost",
      "Linen & amenities",
      "Welcome amenities included",
      "Guest property manual",
      "Direct booking website",
      "Owner dashboard access",
      "Priority 24hr support",
      "Quarterly strategy review",
    ],
    highlighted: true,
  },
];

const ADDONS = [
  { service: "Professional Photoshoot", price: "On quotation" },
  { service: "Annual Deep Clean", price: "On quotation" },
  { service: "MTA Licensing", price: "€150 + authority fees" },
  { service: "Procurement & Setup Works", price: "€25/hr + VAT" },
  { service: "Mail & Bills Handling", price: "€10/month" },
  { service: "Interior Design", price: "On quotation" },
];

export default function PricingSection({ onOpenWizard }: PricingSectionProps) {
  const ref = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });
  const y = useTransform(scrollYProgress, [0, 1], [30, -30]);

  return (
    <section id="pricing" ref={ref} className="min-h-screen flex items-center py-20 sm:py-28">
      <div className="section-container w-full">
        <motion.div style={{ y }}>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <p className="micro-type text-primary mb-3">Pricing</p>
            <h2 className="font-serif text-3xl sm:text-4xl font-semibold text-foreground">
              Simple, <span className="gold-text">transparent</span> pricing
            </h2>
            <p className="text-muted-foreground mt-4 max-w-md mx-auto">No setup fees. No hidden costs. You only pay when you earn.</p>
          </motion.div>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {PLANS.map((plan, i) => (
            <motion.div
              key={plan.name}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.15 }}
              className={`glass-surface rounded-lg p-8 relative ${
                plan.highlighted ? "border-primary/50 shadow-[var(--shadow-gold)]" : ""
              }`}
            >
              {plan.highlighted && (
                <span className="absolute -top-3 left-8 micro-type px-3 py-1 bg-primary text-primary-foreground rounded-full text-[0.6rem]">
                  Most Popular
                </span>
              )}
              <h3 className="font-serif text-2xl font-semibold text-foreground mb-1">{plan.name}</h3>
              <div className="flex items-baseline gap-1 mb-1">
                <span className="text-4xl font-bold text-primary">{plan.price}</span>
                <span className="text-sm text-muted-foreground">{plan.subtitle}</span>
              </div>
              <p className="text-sm text-muted-foreground mb-6">{plan.desc}</p>
              <ul className="space-y-3 mb-8">
                {plan.features.map((f) => (
                  <li key={f} className="flex items-center gap-2 text-sm text-foreground">
                    <Check size={14} className="text-primary flex-shrink-0" />
                    {f}
                  </li>
                ))}
              </ul>
              <button
                onClick={onOpenWizard}
                className={`w-full py-3 text-sm font-semibold rounded transition-colors ${
                  plan.highlighted
                    ? "bg-primary text-primary-foreground hover:bg-gold-light"
                    : "border border-border text-foreground hover:border-primary hover:text-primary"
                }`}
              >
                Get Started
              </button>
            </motion.div>
          ))}
        </div>

        {/* Add-on services */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-16 max-w-3xl mx-auto"
        >
          <h3 className="font-serif text-xl font-semibold text-foreground text-center mb-6">
            Available on both plans — charged separately
          </h3>
          <div className="glass-surface rounded-lg divide-y divide-border/50">
            {ADDONS.map((a) => (
              <div key={a.service} className="flex items-center justify-between px-6 py-3.5">
                <span className="text-sm text-foreground">{a.service}</span>
                <span className="text-sm text-primary font-medium">{a.price}</span>
              </div>
            ))}
          </div>
          <p className="text-xs text-muted-foreground text-center mt-6 max-w-lg mx-auto leading-relaxed">
            Net Room Revenue is calculated on gross rental income, excluding platform commissions,
            VAT, cleaning fees, damage deposits, and optional extras. All agreements governed by Malta law.
          </p>
        </motion.div>
      </div>
    </section>
  );
}
